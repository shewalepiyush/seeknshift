
package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.DetailsDto;
import com.app.dto.ReviewDto;
import com.app.dto.ShifterDto;
import com.app.dto.UserDto;
import com.app.pojos.Advertise;
import com.app.pojos.Review;
import com.app.pojos.Shifter;
import com.app.pojos.User;
import com.app.service.IAdminService;

@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private IAdminService adminService;

	@GetMapping("/listAdvertisement")
	public List<Advertise> ListAdvertisement() {
		System.out.println("in method of list advertisement ");
		return adminService.ListAdvertisement();
	}

	@GetMapping("/listSeeker")
	public List<User> ListSeeker() {
		System.out.println("in method of list seeker");
		return adminService.ListSeeker();
	}
	
	@GetMapping("/listReview")
	public List<ReviewDto> ListReview() {
		System.out.println("in method of list review");
		return adminService.ListReview();
	}

	@GetMapping("/listShifter")
	public List<ShifterDto> ListShifter() {
		System.out.println("in method of list Shifter");
		return adminService.ListShifter();
	}
	
	@GetMapping("/changeStatus/{userId}")
	public ResponseEntity<?> changeStatus(@PathVariable int userId) {
		System.out.println("in method of changeStatus");
		adminService.changeStatus(userId);
		return ResponseEntity.ok("changed Status");
	}


	@GetMapping("/listOwner")
	public List<User> ListOwner() {
		System.out.println("in method of list Owner");
		return adminService.ListOwner();
	}

	@GetMapping("/deactivate/{id}")
	public String deactivateUser(@PathVariable int id) {
		adminService.deactivateUser(id);
		return "user deactivated";
	}
	
	@GetMapping("/getDetails")
		public DetailsDto getDetails() {
			return adminService.getDetails();
		}
	

	@PostMapping("/login")
	public User adminLogin(@RequestBody User u) {
		System.out.println("in login admin function of email");
		String email = u.getEmail();
		String password = u.getPassword();
		System.out.println("email : "+u.getEmail());
		System.out.println("pwd: "+u.getPassword());
		System.out.println((u.getEmail() == email));
		if ((u.getEmail() == email) && (u.getPassword() == password)) 
		{
			System.out.println("inside if of login ");
			return u;
		}	
		else
			return null;
	}
}
