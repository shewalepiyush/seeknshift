package com.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dao.AdvertisementRepository;
import com.app.dto.AdvertisementDto;
import com.app.pojos.Advertise;
import com.app.pojos.User;
import com.app.service.IOwnerService;

@RestController
@CrossOrigin
@RequestMapping("/owner")
public class OwnerController {

	@Autowired
	private IOwnerService ownerService;
	
	@Autowired
	private AdvertisementRepository aRepo;

	@PostMapping("/add-advertisement")
	public ResponseEntity<?> addAdvertisement(@RequestBody AdvertisementDto ADto) {
		System.out.println("in method of add advertisement " + ADto);
		return ResponseEntity.ok(ownerService.addAdvertise(ADto));
	}

	@DeleteMapping("/delete-advertisement/{advertiseId}")
	public ResponseEntity<?> deleteAdvertisement(@PathVariable int advertiseId) {
		System.out.println("in method of delete advertisement");
		ownerService.deleteAdvertise(advertiseId);
		return ResponseEntity.ok("advertise deleted");
	}

	@PutMapping("/update-advertisement/{advertiseId}")
	public ResponseEntity<?> updateAdvertisement(@RequestBody AdvertisementDto ADto, @PathVariable int advertiseId) {
		System.out.println("in method of update advertisement " + ADto);
		ownerService.updateAdvertise(ADto, advertiseId);
		return ResponseEntity.ok("advertise updated");
	}

	@GetMapping("/get-advertisement/{advertiseId}")
	public ResponseEntity<?> getAdvertisement(@PathVariable int advertiseId) {
		System.out.println("in method of get advertisement ");
		Advertise a = ownerService.getAdvertise(advertiseId);
		return ResponseEntity.ok(a);
	}

	@GetMapping("/approve-request/{requestId}")
	public ResponseEntity<?> approveRequest(@PathVariable int requestId) {
		System.out.println("in method of approve Request");
		ownerService.approveRequest(requestId);
		return ResponseEntity.ok("request approved");
	}

	@GetMapping("/listRequests/{userId}")
	public ResponseEntity<?> listRequests(@PathVariable int userId) {
		System.out.println("in list Request of Owner");
		return ResponseEntity.ok(ownerService.getSeekerRequests(userId));
	}

	@GetMapping("/get-alladvertisements/{userId}")
	public ResponseEntity<?> getAllAdvertisements(@PathVariable int userId) {
		System.out.println("in method of get All Advertisements");
		return ResponseEntity.ok(ownerService.getAllAdvertisements(userId));
	}
	
	@PostMapping("/image/{id}")
	public ResponseEntity<?> imageUpload(@PathVariable int id, @RequestBody MultipartFile file) throws Exception {
		System.out.println("in image uploading function of " + id);
		Optional<Advertise> Optional = aRepo.findByAdvertiseId(id);
		String uploadLocation = System.getProperty("user.dir") + "/../frontend/user-panel/src/assets/Images/";
		System.out.println(System.getProperty("user.dir"));
		if (Optional.isPresent()) {
			Advertise a = Optional.get();
			if (a != null) {
				a.setImage(file.getOriginalFilename());
				ownerService.uploadImage(a);
				System.out.println(file.getOriginalFilename());
				file.transferTo(new File(uploadLocation, file.getOriginalFilename()));
			}
			return new ResponseEntity<>(file.getOriginalFilename(), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
