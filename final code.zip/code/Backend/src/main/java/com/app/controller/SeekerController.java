package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.FilteredAdvertise;
import com.app.dto.SeekerReqDto;
import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;
import com.app.pojos.Review;
import com.app.service.ISeekerService;

@RestController
@CrossOrigin
@RequestMapping("/seeker")
public class SeekerController {
	@Autowired
	private ISeekerService seekerService;

	@PostMapping("/addRequestToShifter")
	public ResponseEntity<?> updateProfile(@RequestBody SeekerReqDto seekerReq) throws Exception {
		System.out.println("in add RequestToShifter function of seeker");
		seekerService.addRequestToShifter(seekerReq);
		return ResponseEntity.ok("Request to Shifter successfuly added");
	}

	@GetMapping("/listRequests/{seekerId}")
	public ResponseEntity<?> listRequests(@PathVariable int seekerId) throws Exception {
		System.out.println("in listRequest() of seekerController");

		return ResponseEntity.ok(seekerService.listSeekerRequests(seekerId));
	}

	@PostMapping("/addReviewToShifter/{rateEntryId}")
	public ResponseEntity<?> addReviewToShifter(@PathVariable Integer rateEntryId, @RequestBody Review review)
			throws Exception {
		System.out.println("in add Review to Shifter function of seeker");
		seekerService.addReviewToShifter(rateEntryId, review);
		return ResponseEntity.ok("Review successfuly added");
	}

	@GetMapping("/addRequestToOwner/{advertiseId}/{userId}")
	public ResponseEntity<?> addRequestToOwner(@PathVariable Integer advertiseId, @PathVariable Integer userId)
			throws Exception {
		System.out.println("in add Request function of seeker");
		seekerService.addRequestToOwner(advertiseId, userId);
		return ResponseEntity.ok("Request successfuly added");
	}

	@PostMapping("/listFilteredAdvertise")
	public ResponseEntity<?> listFilteredAdvertise(@RequestBody FilteredAdvertise filterObj) throws Exception {
		System.out.println("in listFilteredAdvertise function of seeker");
		return ResponseEntity.ok(seekerService.listFilteredAdvertise(filterObj));
	}

	@PostMapping("/listFilteredRateEntry")
	public ResponseEntity<?> listFilteredRateEntry(@RequestBody RateEntry filterObj) throws Exception {
		System.out.println("in listFilteredRateEntry function of seeker");
		return ResponseEntity.ok(seekerService.listFilteredRateEntry(filterObj));
	}

	@GetMapping("/listAllAdvertisement")
	public List<Advertise> ListAdvertisement() {
		System.out.println("in method of list all advertisement of Seeker ");
		return seekerService.ListAdvertisement();
	}

	@DeleteMapping("/cancelRequest/{requestId}")
	public ResponseEntity<?> cancelRequest(@PathVariable int requestId) throws Exception {
		System.out.println("in cancelRequest() of seekerController");
		seekerService.cancelRequest(requestId);
		return ResponseEntity.ok("Request deleted successfuly");
	}
}
