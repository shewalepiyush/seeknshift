package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.CustomResponse;
import com.app.dto.ShifterDto;
import com.app.pojos.RateEntry;
import com.app.pojos.Shifter;
import com.app.service.IShifterService;

@RestController
@CrossOrigin
@RequestMapping("/shifter")
public class ShifterController {
	@Autowired
	private IShifterService shifterService;

	@PostMapping("/addcompany")
	public ResponseEntity<?> updateProfile(@RequestBody ShifterDto shifterDto) throws Exception {
		System.out.println("in add company function of shifter");
		shifterService.addCompany(shifterDto);
		return ResponseEntity.ok("successfuly placed");
	}

	@PostMapping("/addrateentry")
	public ResponseEntity<?> addRateEntry(@RequestBody ShifterDto shifterDto) throws Exception {
		System.out.println("in add company function of shifter");
		shifterService.addRateEntry(shifterDto);
		return ResponseEntity.ok("successfuly placed");
	}

	@DeleteMapping("/delete-rateentry/{id}")
	public ResponseEntity<?> deleterateentry(@PathVariable int id) {
		System.out.println("in method of delete rateEntry");
		shifterService.deleteRateEntry(id);
		return ResponseEntity.ok("RateEntry deleted");
	}

	@PostMapping("/update-rateentry/{id}")
	public ResponseEntity<?> updaterateentry(@RequestBody ShifterDto rateEntryHobj, @PathVariable int id) {
		System.out.println("in method of update rateEntry " + rateEntryHobj);
		shifterService.updateRateEntry(rateEntryHobj, id);
		return ResponseEntity.ok("RateEntry updated");
	}

	@GetMapping("/get-rateentry/{id}")
	public ResponseEntity<?> getRateEntry(@PathVariable int id) {
		System.out.println("in method of get rateEntry ");
		RateEntry a = shifterService.getRateEntry(id);
		return ResponseEntity.ok(a);
	}

	@GetMapping("/get-allrateentries/{id}")
	public ResponseEntity<?> getAllRateEntries(@PathVariable int id) {
		System.out.println("in method of get All rateEntries");
		List<RateEntry> rateEntries = shifterService.getAllRateEntry(id);
		return ResponseEntity.ok(rateEntries);
	}

	@GetMapping("/listRequests/{id}")
	public ResponseEntity<?> listRequests(@PathVariable int id) throws Exception {
		System.out.println("in list Request of shifter");
		return ResponseEntity.ok(shifterService.getSeekerRequests(id));
	}

	@GetMapping("/listReviews/{id}")
	public ResponseEntity<?> listReviews(@PathVariable int id) throws Exception {
		System.out.println("in list Review of shifter");
		return ResponseEntity.ok(shifterService.getSeekerRequests(id));
	}

	@GetMapping("/approve-request/{id}")
	public ResponseEntity<?> approveRequest(@PathVariable int id) {
		System.out.println("in method of approve Request");
		shifterService.approveRequest(id);
		return ResponseEntity.ok("request approved");
	}

	@GetMapping("/company-name/{id}")
	public ResponseEntity<?> companyname(@PathVariable int id) {
		System.out.println("in method of companyname");
		Shifter shifter = shifterService.getcompanyname(id);
		if (shifter != null) {
			String companyName = shifter.getCompanyName();
			if (companyName != null)
				return ResponseEntity.ok(new CustomResponse(true, companyName));
		}
		return ResponseEntity.ok(new CustomResponse(false, null));
	}
}