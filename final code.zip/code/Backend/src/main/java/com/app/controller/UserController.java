package com.app.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dao.UserRepository;
import com.app.dto.CustomResponse;
import com.app.dto.UserDto;
import com.app.pojos.User;
import com.app.service.IAdminService;
import com.app.service.IUserService;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserService userService;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private IAdminService adminService;

	@Autowired
	private UserRepository userRepo;

//	@PostMapping("/signup")
//	public ResponseEntity<?> registerOwner(@RequestBody User u) {
//		System.out.println("in owner signup " + u);
//		User user = userService.registerNewUser(u);
//		String userId = Integer.toString(user.getUserId());
//		String link = "http://localhost:4000/user/activate/*";
//		String finalLink = link.replace("*", userId);
//		adminService.sendSimpleEmail(user.getEmail().toString(), "User Registeration",
//				"Welcome to SEEKNSHIFT...To confirm your account, please click here : \"\n" + finalLink);
//		return ResponseEntity.ok(user);
//	}

	@PostMapping("/image/{id}")
	public ResponseEntity<?> imageUpload(@PathVariable int id, @RequestBody MultipartFile file) throws Exception {

		System.out.println("in image uploading function of " + id);
		Optional<User> Optional = userRepo.findById(id);
		String uploadLocation = System.getProperty("user.dir") + "/../frontend/user-panel/src/assets/Images/";
		System.out.println(System.getProperty("user.dir"));
		if (Optional.isPresent()) {
			User u = Optional.get();
			if (u != null) {
				u.setProfile_pic(file.getOriginalFilename());
				userService.uploadImage(u);
				System.out.println(file.getOriginalFilename());
				file.transferTo(new File(uploadLocation, file.getOriginalFilename()));
			}
			return new ResponseEntity<>(file.getOriginalFilename(), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/image/{id}")
	public ResponseEntity<?> imageDownload(@PathVariable int id) throws Exception {
		System.out.println("in image downloading function of " + id);
		Optional<User> Optional = userRepo.findById(id);
		String downloadLocation = System.getProperty("user.dir") + "/../frontend/user-panel/src/assets/Images/";
		System.out.println(System.getProperty("user.dir"));
		if (Optional.isPresent()) {
			User u = Optional.get();
			if (u != null) {
				Path path = Paths.get(downloadLocation, u.getProfile_pic());
				InputStreamResource input = new InputStreamResource(new FileInputStream(path.toFile()));
				HttpHeaders headers = new HttpHeaders();
				headers.add("content-type", Files.probeContentType(path));
				System.out.println(input.toString());
				return ResponseEntity.ok().headers(headers).body(input);
			}
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@PostMapping("/signup")
	public ResponseEntity<?> addUser(@RequestBody User u) throws Exception {
		System.out.println("in signup user function of " + u);
		String pathToAttachment = System.getProperty("user.dir") + "/Utils/activation_link.html";
		File file = new File(pathToAttachment);
		User user = userService.registerNewUser(u);
		System.out.println(u);
		if (user != null) {
			String activationLink = "http://localhost:4000/user/activate/" + user.getUserId();
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = reader.readLine();
			String content = "";
			while (line != null) {
				content = content + line + System.lineSeparator();
				line = reader.readLine();
			}
			reader.close();
			content = content.replaceAll("firstName", user.getFirstName());
			content = content.replaceAll("lastName", user.getLastName());
			content = content.replaceAll("activationLink", activationLink);
			MimeMessage message = emailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom("seeknshift@gmail.com");
			helper.setTo(user.getEmail());
			helper.setSubject("user registration");
			helper.setText(content, true);
			emailSender.send(message);
		}
		return ResponseEntity.ok(user);
	}

	@GetMapping("/activate/{id}")
	public ResponseEntity<?> activateUser(@PathVariable int id) throws Exception {
		User u = userService.activateUser(id);
		String pathToAttachment = System.getProperty("user.dir") + "/Utils/activation_result.html";
		File file = new File(pathToAttachment);
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = reader.readLine();
		String content = "";
		while (line != null) {
			content = content + line + System.lineSeparator();
			line = reader.readLine();
		}
		reader.close();
		content = content.replaceAll("loginLink", "http://localhost:4200/user/login");
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		helper.setFrom("seeknshift@gmail.com");
		helper.setTo(u.getEmail());
		helper.setSubject("user activation");
		helper.setText(content, true);
		emailSender.send(message);
		return ResponseEntity.ok("user activated... please check mail inbox to login...");
	}

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody User u1) {
		System.out.println("in login user function of email =" + u1.getEmail() + " " + u1.getPassword());
		User u = userService.getUserByEmailAndPassword(u1.getEmail(), u1.getPassword());
		if ( u != null && u.getStatus() == 1)
			return ResponseEntity.ok(new CustomResponse(true, u));
			return  ResponseEntity.ok(new CustomResponse(false, null));
	}

	@PostMapping("/update-profile")
	public ResponseEntity<?> updateProfile(@RequestBody UserDto userDto) throws Exception {
		System.out.println("in update user function of " + userDto);
		User u = userService.updateUser(userDto);
		if (u != null)
			return ResponseEntity.ok(u);
		return new ResponseEntity<>("user not found something went wrong", HttpStatus.NOT_FOUND);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable int id) {
		userService.deleteUser(id);
	}

//	@PostMapping("/activate/{id}")
//	public void activateUser(@PathVariable int id) {
//		userService.activateUser(id);
//	}

	@GetMapping("/addpoints/{id}/{points}")
	public ResponseEntity<?> addPoints(@PathVariable int id, @PathVariable int points) {
		return ResponseEntity.ok(userService.addPoints(id, points));
	}

	@GetMapping("/getpoints/{id}")
	public ResponseEntity<?> getPoints(@PathVariable int id) {
		return ResponseEntity.ok(userService.addPoints(id, 0));
	}

	@DeleteMapping("/deletePoints")
	public String deletePoints(@RequestBody User u1) {
		int points;
		System.out.println("in delete Points user function of email =" + u1.getEmail());
		points = userService.deletePoints(u1);
		System.out.println(points);
		return "Current Points is " + points;
	}

	@GetMapping("/getProfile/{userId}")
	public ResponseEntity<?> getProfile(@PathVariable int userId) {
		System.out.println("in get profile function ");
		User user = userService.getProfile(userId);
		return ResponseEntity.ok(user);
	}
}
