package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Advertise;

public interface AdvertisementRepository  extends JpaRepository<Advertise, Integer>{
	Optional<Advertise> findByAdvertiseId(Integer id);
	Optional<Advertise> findByTitle(String s);
}
