package com.app.dao;

public class IOwnerDao {

}
