package com.app.dao;

public class OwnerDaoImpl {

}
