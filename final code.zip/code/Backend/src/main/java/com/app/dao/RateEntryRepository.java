package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;

public interface RateEntryRepository extends JpaRepository<RateEntry, Integer>{
	Optional<RateEntry> findByEntryId(Integer id);
}
