package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.SeekerRequest;

public interface RequestRepository extends JpaRepository<SeekerRequest, Integer> {
	Optional<SeekerRequest> findByRequestId(int id);
	Optional<SeekerRequest> findByUser(int id);
}
