package com.app.dto;

public class AdvertisementDto {

	private byte[] image;
	private String title;
	private String description;
	private String propertyType;
	private int bhk;
	private double price;
	private String city;
	private String state;
	private String location;
	private int userId;

	public AdvertisementDto() {
	}

	public AdvertisementDto(byte[] image, String title, String description, String propertyType, int bhk, double price,
			String city, String state, String location, int userId) {
		super();
		this.image = image;
		this.title = title;
		this.description = description;
		this.propertyType = propertyType;
		this.bhk = bhk;
		this.price = price;
		this.city = city;
		this.state = state;
		this.location = location;
		this.userId = userId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public int getBhk() {
		return bhk;
	}

	public void setBhk(int bhk) {
		this.bhk = bhk;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
