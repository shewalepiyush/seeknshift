package com.app.dto;

public class CustomResponse {
	public boolean status;
	public Object res;

	public CustomResponse(boolean status, Object res) {
		this.status = status;
		this.res = res;
	}

}
