package com.app.dto;

public class DetailsDto {
	private int seekers;
	private int shifters;
	private int owners;
	private int advertises;
	public DetailsDto(int seekers, int shifters, int owners, int advertises) {
		super();
		this.seekers = seekers;
		this.shifters = shifters;
		this.owners = owners;
		this.advertises = advertises;
	}
	public DetailsDto() {
	}
	public int getSeekers() {
		return seekers;
	}
	public void setSeekers(int seekers) {
		this.seekers = seekers;
	}
	public int getShifters() {
		return shifters;
	}
	public void setShifters(int shifters) {
		this.shifters = shifters;
	}
	public int getOwners() {
		return owners;
	}
	public void setOwners(int owners) {
		this.owners = owners;
	}
	public int getAdvertises() {
		return advertises;
	}
	public void setAdvertises(int advertises) {
		this.advertises = advertises;
	}
	
}
