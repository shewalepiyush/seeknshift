package com.app.dto;

public class FilteredAdvertise {
	
	private String propertyType;
	private double minPrice;
	private double maxPrice;
	private int bhk;
	private String state;
	private String city;
	
	
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public double getminPrice() {
		return minPrice;
	}
	public void setminPrice(double minPrice) {
		this.minPrice = minPrice;
	}
	public double getMaxPrice() {
		return maxPrice;
	}
	public void setMaxPrice(double maxPrice) {
		this.maxPrice = maxPrice;
	}
	public int getBhk() {
		return bhk;
	}
	public void setBhk(int bhk) {
		this.bhk = bhk;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "FilteredAdvertise [propertyType=" + propertyType + ", minPrice=" + minPrice + ", maxPrice=" + maxPrice
				+ ", bhk=" + bhk + ", state=" + state + ", city=" + city + "]";
	}
	
}
