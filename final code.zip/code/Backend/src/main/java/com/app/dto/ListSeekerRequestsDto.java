package com.app.dto;

import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;
import com.app.pojos.Role;

public class ListSeekerRequestsDto {
	private int requestId;
	private Advertise advertise = null;
	private RateEntry rateEntry = null;
	private String phone;
	private Role role;
	private String name = "";
	private int approval;

	public ListSeekerRequestsDto() {
		this.requestId = 0;
		this.approval = 0;
	}

	public ListSeekerRequestsDto(Advertise advertise, RateEntry rateEntry, String phone, Role role, String name) {
		super();
		this.advertise = advertise;
		this.rateEntry = rateEntry;
		this.phone = phone;
		this.role = role;
		this.name = name;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Advertise getAdvertise() {
		return advertise;
	}

	public void setAdvertise(Advertise advertise) {
		this.advertise = advertise;
	}

	public RateEntry getRateEntry() {
		return rateEntry;
	}

	public void setRateEntry(RateEntry rateEntry) {
		this.rateEntry = rateEntry;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name += name;
	}

	public int getApproval() {
		return approval;
	}

	public void setApproval(int approval) {
		this.approval = approval;
	}

	@Override
	public String toString() {
		return "ListSeekerRequestsDto [requestId=" + requestId + ", advertise=" + advertise + ", rateEntry=" + rateEntry
				+ ", phone=" + phone + ", role=" + role + ", name=" + name + ", approval=" + approval + "]";
	}
}
