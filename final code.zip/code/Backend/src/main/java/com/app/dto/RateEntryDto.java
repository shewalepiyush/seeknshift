package com.app.dto;

public class RateEntryDto {

	int rateEntryId;
	String source;
	String destination;
	Double rate;
	String companyName;
	int rating;

	public RateEntryDto() {
		super();
	}

	public RateEntryDto(int rateEntryId, String source, String destination, Double rate, String companyName,
			int rating) {
		super();
		this.rateEntryId = rateEntryId;
		this.source = source;
		this.destination = destination;
		this.rate = rate;
		this.companyName = companyName;
		this.rating = rating;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getRateEntryId() {
		return rateEntryId;
	}

	public void setRateEntryId(int rateEntryId) {
		this.rateEntryId = rateEntryId;
	}

	@Override
	public String toString() {
		return "RateEntryDto [rateEntryId=" + rateEntryId + ", source=" + source + ", destination=" + destination
				+ ", rate=" + rate + ", companyName=" + companyName + ", rating=" + rating + "]";
	}

}
