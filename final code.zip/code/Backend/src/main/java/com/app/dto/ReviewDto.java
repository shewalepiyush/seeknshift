package com.app.dto;

public class ReviewDto {
		private int rating; 
		private String companyName;
		private String experience;
		public int getRating() {
			return rating;
		}
		public void setRating(int rating) {
			this.rating = rating;
		}
		public String getCompanyName() {
			return companyName;
		}
		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}
		public String getExperience() {
			return experience;
		}
		public void setExperience(String experience) {
			this.experience = experience;
		}
		@Override
		public String toString() {
			return "ReviewDto [rating=" + rating + ", companyName=" + companyName + ", experience=" + experience + "]";
		}
		public ReviewDto(int rating, String companyName, String experience) {
			super();
			this.rating = rating;
			this.companyName = companyName;
			this.experience = experience;
		}
		public ReviewDto() {
			super();
		}
		
		
}
