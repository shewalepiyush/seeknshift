package com.app.dto;

public class SeekerReqDto {
		private int rateEntryId;
		private int userId;
		
		
		public int getRateEntryId() {
			return rateEntryId;
		}
		public void setRateEntryId(int rateEntryId) {
			this.rateEntryId = rateEntryId;
		}
		
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		
		
}
