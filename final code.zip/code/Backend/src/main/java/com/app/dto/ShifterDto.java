package com.app.dto;

public class ShifterDto {
	private String cName;
	private String email;
	private String source;
	private String destination;
	private double rate ; 
	private int status; 
	private int userId;
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public ShifterDto() {
		// TODO Auto-generated constructor stub
	}
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public ShifterDto(String cName, String email) {
		super();
		this.cName = cName;
		this.email = email;
	}

	public ShifterDto(String cName, String email, int status, int userId) {
		super();
		this.cName = cName;
		this.email = email;
		this.status = status;
		this.userId = userId;
	}
	
}