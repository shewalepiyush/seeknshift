package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "advertise")
public class Advertise {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "advertise_id")
	private Integer advertiseId;
	@Lob
	private String image;
	@Column(name = "title", length = 20)
	private String title;
	@Column(length = 50)
	private String description;
	@Column(name = "property_type", length = 20)
	private String propertyType;
	@Column
	private int bhk;
	@Column
	private double price;

	// Relational Mapping

	@OneToOne(mappedBy = "advertise", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("address")
	private Address address;

	@OneToMany(mappedBy = "advertise", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JsonIgnore
	private List<SeekerRequest> seekerRequests = new ArrayList<>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name = "owner_id", nullable = false)
	private User owner;

	public Advertise(String title, String description, String propertyType, int bhk, double price,
			Address address, List<SeekerRequest> seekerRequests, User owner) {
		super();
		this.title = title;
		this.description = description;
		this.propertyType = propertyType;
		this.bhk = bhk;
		this.price = price;
		this.address = address;
		this.seekerRequests = seekerRequests;
		this.owner = owner;
	}

	public Advertise() {
	}

	public Integer getAdvertiseId() {
		return advertiseId;
	}

	public void setAdvertiseId(Integer advertiseId) {
		this.advertiseId = advertiseId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
		address.setAdvertise(this);
	}

	public List<SeekerRequest> getSeekerRequests() {
		return seekerRequests;
	}

	public void setSeekerRequests(List<SeekerRequest> seekerRequests) {
		this.seekerRequests = seekerRequests;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public int getBhk() {
		return bhk;
	}

	public void setBhk(int bhk) {
		this.bhk = bhk;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
