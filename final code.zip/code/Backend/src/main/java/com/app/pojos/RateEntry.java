package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "rate_entry")
public class RateEntry {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer entryId;
	@Column(length = 20)
	private String source;
	@Column(length = 20)
	private String destination;
	@Column
	private Double rate;

	// many to one association between entities : owning side
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name = "shifter_id", nullable = false)
	private Shifter shifter;
	
	@OneToMany(mappedBy = "rateEntry", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JsonIgnore
	private List<SeekerRequest> seekerRequests = new ArrayList<>();

	public RateEntry(String source, String destination, Double rate, Shifter shifter) {
		super();
		this.source = source;
		this.destination = destination;
		this.rate = rate;
		this.shifter = shifter;
	}

	public RateEntry() {

	}

	public Integer getEntryId() {
		return entryId;
	}

	public void setEntryId(Integer entryId) {
		this.entryId = entryId;
	}

	public Shifter getShifter() {
		return shifter;
	}

	public void setShifter(Shifter shifter) {
		this.shifter = shifter;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	
	
	public List<SeekerRequest> getSeekerRequests() {
		return seekerRequests;
	}

	public void setSeekerRequests(List<SeekerRequest> seekerRequests) {
		this.seekerRequests = seekerRequests;
	}

	@Override
	public String toString() {
		return "RateEntry [source=" + source + ", destination=" + destination + ", rate=" + rate + "]";
	}

}