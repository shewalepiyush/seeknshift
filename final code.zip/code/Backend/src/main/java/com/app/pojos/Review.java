package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "review")
public class Review {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "review_id")
	private Integer reviewId;
	@Column
	private int rating;
	@Column(length = 50)
	private String experience;
	

	// many to one association between entities : owning side
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "shifter_id", nullable = false)
	private Shifter shifter;

	public Review() {
	}

	public Review(int rating, String experience, Shifter shifter) {
		super();
		this.rating = rating;
		this.experience = experience;
		this.shifter = shifter;
	}

	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}

	public Shifter getShifter() {
		return shifter;
	}

	public void setShifter(Shifter shifter) {
		this.shifter = shifter;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}


}
