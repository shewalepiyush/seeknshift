package com.app.pojos;

public enum Role {
	SEEKER, OWNER , SHIFTER;
}
