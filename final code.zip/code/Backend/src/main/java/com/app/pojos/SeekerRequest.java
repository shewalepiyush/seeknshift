package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "seeker_request")
public class SeekerRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_id")
	private Integer requestId;

	// many to one association between entities : owning side
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "advertise_id")
	private Advertise advertise;

	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	//@JsonIgnore
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "entry_id")
	private RateEntry rateEntry;

	@Column(nullable = false)
	private int approval;

	public SeekerRequest() {
		super();
	}

	public SeekerRequest(Advertise advertise, User user) {
		super();
		this.advertise = advertise;
		this.user = user;
		this.approval = 0;
	}

	public SeekerRequest(RateEntry r, User u) {
		super();
		this.rateEntry = r;
		this.user = u;
		this.approval = 0;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public Advertise getAdvertise() {
		return advertise;
	}

	public void setAdvertise(Advertise advertise) {
		this.advertise = advertise;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getApproval() {
		return approval;
	}

	public void setApproval(int approval) {
		this.approval = approval;
	}

	public RateEntry getRateEntry() {
		return rateEntry;
	}

	public void setRateEntry(RateEntry rateEntry) {
		this.rateEntry = rateEntry;
	}
	

}