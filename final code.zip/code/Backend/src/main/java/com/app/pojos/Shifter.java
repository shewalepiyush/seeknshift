package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="shifter")
public class Shifter {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column (name = "shifter_id")
	private Integer shifterId;
	@Column (name = "company_name")
	private String companyName;
	@Column
	private int rating;
	
	@OneToOne
	@JoinColumn(name="user_id",nullable =false)
	private User user;
	
	@OneToMany(mappedBy = "shifter",cascade = CascadeType.ALL,orphanRemoval = true , fetch = FetchType.LAZY)
	private List<Review> review=new ArrayList<>();
	
	@OneToMany(mappedBy = "shifter",cascade = CascadeType.ALL,orphanRemoval = true , fetch = FetchType.LAZY)
	private List<RateEntry> rateEntry=new ArrayList<>();
	
	public List<Review> getReview() {
		return review;
	}

	public void setReview(List<Review> review) {
		this.review = review;
	}

	public List<RateEntry> getRateEntry() {
		return rateEntry;
	}

	public void setRateEntry(List<RateEntry> rateEntry) {
		this.rateEntry = rateEntry;
	}

	public Shifter() {

	}

	public Shifter(String companyName, int rating, User user) {
		super();
		this.companyName = companyName;
		this.rating = rating;
		this.user = user;
	}


	public Integer getShifterId() {
		return shifterId;
	}
	public void setShifterId(Integer shifterId) {
		this.shifterId = shifterId;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Shifter [companyName=" + companyName + ", rating=" + rating + "]";
	}
	
}