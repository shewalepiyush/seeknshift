package com.app.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Integer userId;
	@Column(name = "first_name", length = 20)
	private String firstName;
	@Column(name = "last_name", length = 20)
	private String lastName;
	@Column(name = "date_of_birth")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	@Column(length = 13)
	private String phone;
	@Column(length = 50, unique = true)
	private String email;
	@Column(length = 100)
	private String password;
	@Enumerated(EnumType.STRING)
	@Column
	private Role role;
	@Lob
	private String profile_pic;

	@OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
	@JsonManagedReference
	private Address address;

	@OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
	@JsonIgnore
	private Shifter shifter;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonIgnore
	// @JsonIgnoreProperties("user")
	private List<SeekerRequest> seeker = new ArrayList<>();

	@OneToMany(mappedBy = "owner", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonIgnore
	private List<Advertise> advertise = new ArrayList<>();

	@Column(nullable = false)
//	@Type(type = "org.hibernate.NumericBooleanType")
	private int status;

	@Column
	private int points;

	public User(String firstName, String lastName, LocalDate dateOfBirth, String phone, String email, String password,
			Role role, String profile_pic, int points) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.password = password;
		this.role = role;
		this.profile_pic = profile_pic;
		this.status = 0;
		this.points = points;
		System.out.println("in param const of user");
	}

	public User(String firstName, String lastName, String phone, String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.email = email;
	}

	public User() {
		super();
		this.firstName = "NA";
		this.lastName = "NA";
		this.phone = "NA";
		this.email = "NA";
		this.password = "NA";
		this.status = 0;
		this.points = 0;
		System.out.println("in param less const of user");
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
		address.setUser(this);
		System.out.println("in setter of address");
	}

	public Shifter getShifter() {
		return shifter;
	}

	public void setShifter(Shifter shifter) {
		this.shifter = shifter;
	}

	public List<SeekerRequest> getSeeker() {
		return seeker;
	}

	public void setSeeker(List<SeekerRequest> seeker) {
		this.seeker = seeker;
	}

	public List<Advertise> getAdvertise() {
		return advertise;
	}

	public void setAdvertise(List<Advertise> advertise) {
		this.advertise = advertise;
	}

	public void addAdvertise(Advertise advertise) {
		this.advertise.add(advertise);
		advertise.setOwner(this);
	}

	public String getFirstName() {
		System.out.println("in setter of first name");
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getProfile_pic() {
		return profile_pic;
	}

	public void setProfile_pic(String profile_pic) {
		this.profile_pic = profile_pic;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	// add helper methods : in bi dir association
	public void addAddress(Address a) {
		this.address = a;
		a.setUser(this);
	}

	public void removeAddress(Address a) {
		this.address = null;
		a.setUser(null);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", phone=" + phone + ", email=" + email + ", password=" + password + ", role=" + role
				+ ", profile_pic=" + profile_pic + ", address=" + address + ", shifter=" + shifter + ", seeker="
				+ seeker + ", advertise=" + advertise + ", status=" + status + ", points=" + points + "]";
	}

}