package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.app.dao.AdminRepository;
import com.app.dao.AdvertisementRepository;
import com.app.dao.ReviewRepository;
import com.app.dao.ShifterRepository;
import com.app.dao.UserRepository;
import com.app.dto.DetailsDto;
import com.app.dto.ReviewDto;
import com.app.dto.ShifterDto;
import com.app.dto.UserDto;
import com.app.pojos.Address;
import com.app.pojos.Advertise;
import com.app.pojos.Review;
import com.app.pojos.Role;
import com.app.pojos.SeekerRequest;
import com.app.pojos.Shifter;
import com.app.pojos.User;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {
	@Autowired
	private AdvertisementRepository aRepo;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ShifterRepository shifterRepo;

	@Autowired
	private AdminRepository adminRepo;

	@Autowired
	private ReviewRepository reviewRepo;

	@Override
	public List<Advertise> ListAdvertisement() {
		List<Advertise> listAdvertise = aRepo.findAll();
		Advertise a = null;
		if (!listAdvertise.isEmpty())
			return listAdvertise;
		else
			return null;
	}

	@Override
	public void changeStatus(int userId) {
		Optional<User> optional = userRepo.findByUserId(userId);
		if (optional.isPresent()) {
			User user = optional.get();
			if (user.getStatus() == 1)
				user.setStatus(0);
			else
				user.setStatus(1);
			userRepo.save(user);
		}
	}

	@Override
	public List<User> ListSeeker() {
		List<User> listSeeker = adminRepo.findByRole(Role.SEEKER);
		if (!listSeeker.isEmpty())
			return listSeeker;
		else
			return null;
	}

	@Override
	public List<ShifterDto> ListShifter() {
		List<ShifterDto> shifters = new ArrayList<>();
		List<User> listShifters = adminRepo.findByRole(Role.SHIFTER);
		for (User shifter : listShifters) {
			ShifterDto shifterDto = new ShifterDto(shifter.getShifter().getCompanyName(), shifter.getEmail(),
					shifter.getStatus(), shifter.getUserId());
			shifters.add(shifterDto);
		}
		return shifters;
	}

	@Override
	public List<User> ListOwner() {
		List<User> listOwner = adminRepo.findByRole(Role.OWNER);
		if (!listOwner.isEmpty())
			return listOwner;
		else
			return null;
	}

	@Override

	public String deactivateUser(int id) {
		Optional<User> optional = userRepo.findByUserId(id);
		if (optional.isPresent()) {
			User u = optional.get();
			sendSimpleEmail(u.getEmail().toString(), "user deactivated", "user is deactivated, contact support team");
			u.setStatus(0);
			userRepo.save(u);
		}
		return "User Deactivated";
	}

	public void sendSimpleEmail(String to, String subject, String text) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("seeknshift@gmail.com");
		message.setTo(to);
		System.out.println("sending mail to " + to);
		message.setSubject(subject);
		message.setText(text);
		emailSender.send(message);
	}

	@Override
	public List<ReviewDto> ListReview() {
		List<Review> listReviews = reviewRepo.findAll();
		List<ReviewDto> reviews = new ArrayList<>();
		for (Review review : listReviews) {
			System.out.println("list of reviews : " + review);
			ReviewDto reviewDto = new ReviewDto(review.getRating(), review.getShifter().getCompanyName(),
					review.getExperience());
			reviews.add(reviewDto);
		}
		return reviews;
	}

	@Override
	public DetailsDto getDetails() {
		int shifterCount = 0, ownerCount = 0, seekerCount = 0;
		List<User> users = userRepo.findAll();
		for (User user : users) {
			if (user.getRole().equals(Role.OWNER))
				ownerCount += 1;
			else if (user.getRole().equals(Role.SEEKER))
				seekerCount += 1;
			else if (user.getRole().equals(Role.SHIFTER))
				shifterCount += 1;
		}
		int advertiseCount = userRepo.findAll().size();
		DetailsDto detailsDto = new DetailsDto(seekerCount, shifterCount, ownerCount, advertiseCount);
		return detailsDto;
	}

}