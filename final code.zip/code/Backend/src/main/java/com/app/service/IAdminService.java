package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.app.dto.DetailsDto;
import com.app.dto.ReviewDto;
import com.app.dto.ShifterDto;
import com.app.dto.UserDto;
import com.app.pojos.Advertise;
import com.app.pojos.Review;
import com.app.pojos.User;

public interface IAdminService {
	List<Advertise> ListAdvertisement();

	List<User> ListSeeker();
	
	List<ShifterDto> ListShifter();

	List<User> ListOwner();

	String deactivateUser(int id);
	
	public void changeStatus(int userId);

	//public List<Review> ListReview(Integer id);
	
	public void sendSimpleEmail(String to, String subject, String text);

	List<ReviewDto> ListReview();

	DetailsDto getDetails();

}
