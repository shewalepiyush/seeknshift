package com.app.service;

import java.util.List;

import com.app.dto.AdvertisementDto;
import com.app.pojos.Advertise;
import com.app.pojos.SeekerRequest;

public interface IOwnerService {
	Advertise addAdvertise(AdvertisementDto advertiseDto);
	void deleteAdvertise(int advertiseId);
	void updateAdvertise(AdvertisementDto advertiseDto, int advertiseId);
	Advertise getAdvertise(int advertiseId);
	void approveRequest(int requestId);
	List<SeekerRequest> getSeekerRequests(int userId);
	List<Advertise> getAllAdvertisements(int userId);
	Advertise uploadImage(Advertise a);
}
