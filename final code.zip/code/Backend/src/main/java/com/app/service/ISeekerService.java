package com.app.service;

import java.util.List;

import com.app.dto.FilteredAdvertise;
import com.app.dto.ListSeekerRequestsDto;
import com.app.dto.SeekerReqDto;
import com.app.dto.RateEntryDto;
import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;
import com.app.pojos.Review;

public interface ISeekerService {

	void addRequestToShifter(SeekerReqDto seekerReq);

	void addReviewToShifter(Integer id, Review review);

	void addRequestToOwner(Integer advertiseId, Integer userId);

	List<ListSeekerRequestsDto> listSeekerRequests(int seekerId);

	List<Advertise> listFilteredAdvertise(FilteredAdvertise filterObj);

	List<RateEntryDto> listFilteredRateEntry(RateEntry filterObj);

	List<Advertise> ListAdvertisement();

	void cancelRequest(int requestId);

}
