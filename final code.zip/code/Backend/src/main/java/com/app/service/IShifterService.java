package com.app.service;

import java.util.List;

import com.app.dto.ShifterDto;
import com.app.pojos.RateEntry;
import com.app.pojos.Review;
import com.app.pojos.SeekerRequest;
import com.app.pojos.Shifter;

public interface IShifterService {
	void addCompany(ShifterDto shobj);

	void addRateEntry(ShifterDto shifterDto);

	void deleteRateEntry(int id);

	void updateRateEntry(ShifterDto rateEntryHobj, int id);

	RateEntry getRateEntry(int id);

	List<RateEntry> getAllRateEntry(int id);

	List<SeekerRequest> getSeekerRequests(int id);

	List<Review> getSeekerReviews(int userId);

	void approveRequest(int id);

	Shifter getcompanyname(int id);
}