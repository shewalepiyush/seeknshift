package com.app.service;

import com.app.dto.UserDto;
import com.app.pojos.User;

public interface IUserService {
	User getUserByEmailAndPassword(String email, String password);
	User getProfile(int userId);
	User registerNewUser(User user);
	User updateUser(UserDto u);
	User getUserByEmail(String email);
	void deleteUser(int id);
	User activateUser(int id);	
	int addPoints(int id, int points);
	int deletePoints(User seeker);
	User uploadImage(User u);
}
