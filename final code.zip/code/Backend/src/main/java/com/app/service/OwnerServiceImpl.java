package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.AdvertisementRepository;
import com.app.dao.RequestRepository;
import com.app.dao.UserRepository;
import com.app.dto.AdvertisementDto;
import com.app.pojos.Address;
import com.app.pojos.Advertise;
import com.app.pojos.SeekerRequest;
import com.app.pojos.User;

@Service
@Transactional
public class OwnerServiceImpl implements IOwnerService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private AdvertisementRepository aRepo;
	@Autowired
	private RequestRepository rRepo;

	@Override
	public Advertise addAdvertise(AdvertisementDto advertiseDto) {
		Optional<User> optional = userRepo.findById(advertiseDto.getUserId());
		if (optional.isPresent()) {
			User owner = optional.get();
			if (owner.getPoints() > 10) {
				Advertise advertise = new Advertise();
				Address address = new Address();
				advertise.setTitle(advertiseDto.getTitle());
				advertise.setDescription(advertiseDto.getDescription());
				advertise.setPropertyType(advertiseDto.getPropertyType());
				advertise.setBhk(advertiseDto.getBhk());
				advertise.setPrice(advertiseDto.getPrice());
				address.setCity(advertiseDto.getCity());
				address.setState(advertiseDto.getState());
				address.setLocation(advertiseDto.getLocation());
				owner.setPoints(owner.getPoints() - 10);
				advertise.setAddress(address);
				owner.addAdvertise(advertise);
				userRepo.save(owner);
				return aRepo.findByTitle(advertiseDto.getTitle()).get();
			}
		}
		return null;
	}

	@Override
	public void deleteAdvertise(int advertiseId) {
		Optional<Advertise> optional = aRepo.findByAdvertiseId(advertiseId);
		if (optional.isPresent())
			aRepo.delete(optional.get());
	}

	@Override
	public void updateAdvertise(AdvertisementDto advertiseDto, int advertiseId) {
		Optional<Advertise> optional = aRepo.findByAdvertiseId(advertiseId);
		if (optional.isPresent()) {
			Advertise advertise = optional.get();
			Address address = new Address();
			advertise.setTitle(advertiseDto.getTitle());
			advertise.setDescription(advertiseDto.getDescription());
			advertise.setPropertyType(advertiseDto.getPropertyType());
			advertise.setBhk(advertiseDto.getBhk());
			advertise.setPrice(advertiseDto.getPrice());
			advertise.getAddress().setCity(advertiseDto.getCity());
			advertise.getAddress().setLocation(advertiseDto.getLocation());
			advertise.getAddress().setState(advertiseDto.getState());
			aRepo.save(advertise);
		}
	}

	@Override
	public Advertise getAdvertise(int advertiseId) {
		Optional<Advertise> optional = aRepo.findByAdvertiseId(advertiseId);
		Advertise advertise = null;
		if (optional.isPresent()) {
			advertise = optional.get();
		}
		return advertise;
	}

	@Override
	public void approveRequest(int requestId) {
		Optional<SeekerRequest> optional = rRepo.findByRequestId(requestId);
		if (optional.isPresent()) {
			SeekerRequest seekerRequest = optional.get();
			if (seekerRequest.getApproval() == 1)
				seekerRequest.setApproval(0);
			else
				seekerRequest.setApproval(1);
			rRepo.save(seekerRequest);
		}
	}

	@Override
	public List<SeekerRequest> getSeekerRequests(int userId) {
		System.out.println("in owner service getSeekerRequests ");
		Optional<User> optional = userRepo.findById(userId);
		List<SeekerRequest> seekerRequest = new ArrayList<>();
		if (optional.isPresent()) {
			User user = optional.get();
			for (Advertise advertise : user.getAdvertise()) {
				seekerRequest.addAll(advertise.getSeekerRequests());
			}
		}
		return seekerRequest;
	}

	@Override
	public List<Advertise> getAllAdvertisements(int userId) {
		Optional<User> optional = userRepo.findById(userId);
		User user = null;
		List<Advertise> advertise = null;
		if (optional.isPresent()) {
			user = optional.get();
			advertise = user.getAdvertise();
		}
		return advertise;
	}
	
	@Override
	public Advertise uploadImage(Advertise a) {
		Optional<Advertise> optional = aRepo.findByAdvertiseId(a.getAdvertiseId());
		if (optional.isPresent()) {
			return aRepo.save(a);
		}
		return null;
	}
}
