package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.AdvertisementRepository;
import com.app.dao.RateEntryRepository;
import com.app.dao.RequestRepository;
import com.app.dao.UserRepository;
import com.app.dto.FilteredAdvertise;
import com.app.dto.ListSeekerRequestsDto;
import com.app.dto.RateEntryDto;
import com.app.dto.SeekerReqDto;
import com.app.pojos.Address;
import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;
import com.app.pojos.Review;
import com.app.pojos.Role;
import com.app.pojos.SeekerRequest;
import com.app.pojos.Shifter;
import com.app.pojos.User;

@Service
@Transactional
public class SeekerServiceImpl implements ISeekerService {
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private AdvertisementRepository advRepo;

	@Autowired
	private RateEntryRepository rateEntryRepo;

	@Autowired
	private RequestRepository requestRepo;

	@Override
	public void addRequestToShifter(SeekerReqDto seekerReq) {
		User u = null;
		RateEntry r = null;
		System.out.println("Inside seeker-addRequestToShifter()");

		Optional<User> user = userRepo.findById(seekerReq.getUserId());
		Optional<RateEntry> rates = rateEntryRepo.findByEntryId(seekerReq.getRateEntryId());
		if (rates.isPresent()) {

			r = rates.get();
			u = user.get();

			SeekerRequest request = new SeekerRequest(r, u);
			r.getSeekerRequests().add(request);
			// u.getSeeker().add(request);

			// userRepo.save(u);
			rateEntryRepo.save(r);
		}

	}

	@Override
	public void addReviewToShifter(Integer id, Review review) {
		Shifter s = null;
		RateEntry r = null;
		System.out.println("Inside seeker-addReview()");

		Optional<RateEntry> rates = rateEntryRepo.findByEntryId(id);
		if (rates.isPresent()) {

			r = rates.get();
			s = r.getShifter();

			review.setShifter(s);

			s.getReview().add(review);

			rateEntryRepo.save(r);
		}
	}

	@Override
	public void addRequestToOwner(Integer advertiseId, Integer userId) {
		User u = null;
		Advertise a = null;
		System.out.println("Inside seeker-addRequestToOwner()");

		Optional<Advertise> advertise = advRepo.findByAdvertiseId(advertiseId);
		Optional<User> user = userRepo.findById(userId);
			
		if (advertise.isPresent()) {

			a = advertise.get();
			u = user.get();
			
			SeekerRequest request = new SeekerRequest(a, u);

			// u.getSeeker().add(request);
			a.getSeekerRequests().add(request);
			if (u.getPoints() > 10) {
				u.setPoints(u.getPoints()-10);
			// userRepo.save(u);
			advRepo.save(a);}
		}
	}

	@Override
	public List<ListSeekerRequestsDto> listSeekerRequests(int seekerId) {
		System.out.println("in Seeker service listSeekerRequests() ");

		List<ListSeekerRequestsDto> hobjList = new ArrayList<>();

		User seeker = null;
//		Shifter shifter = null;
//		RateEntry rate = null;

		Optional<User> user = userRepo.findById(seekerId);
		if (user.isPresent()) {

			seeker = user.get();

			List<SeekerRequest> seekerRequests = seeker.getSeeker();
			if (!seekerRequests.isEmpty())
				for (SeekerRequest request : seekerRequests) {
					int approval = request.getApproval();

					Shifter shifter = null;
					RateEntry rate = null;

					Advertise adv = null;
					User owner = null;

					String phone = "";

					ListSeekerRequestsDto hobj = new ListSeekerRequestsDto();

					hobj.setRequestId(request.getRequestId());
					hobj.setApproval(approval);

					if (request.getAdvertise() == null) {
						System.out.println(" RateEntryId = " + request.getRequestId());
						rate = request.getRateEntry();
						shifter = rate.getShifter();
						phone += shifter.getUser().getPhone();

						hobj.setRole(Role.SHIFTER);
						hobj.setRateEntry(rate);
						hobj.setAdvertise(null);

						if (approval == 1) {
							System.out.println("inside shifter company name = " + shifter.getCompanyName());
							hobj.setName(shifter.getCompanyName());
							hobj.setPhone(phone);

						}
					} else if (request.getRateEntry() == null) {

						System.out.println(" AdvertiseId  = " + request.getRequestId());

						adv = request.getAdvertise();
						owner = adv.getOwner();
						phone += owner.getPhone();

						hobj.setRole(Role.OWNER);
						hobj.setAdvertise(request.getAdvertise());
						hobj.setRateEntry(null);

						if (approval == 1) {

							System.out.println(
									"In advertise owner name = " + request.getAdvertise().getOwner().getFirstName());
							hobj.setName(request.getAdvertise().getOwner().getFirstName());
							hobj.setPhone(phone);
						}
					}
					System.out.println(hobj.toString());
					hobjList.add(hobj);
					// s.addAll(a.getSeekerRequests());
				}
		}
		return hobjList;
	}

	@Override
	public List<Advertise> listFilteredAdvertise(FilteredAdvertise filterObj) {

		List<Advertise> allAdvertise = advRepo.findAll();
		List<Advertise> filteredAdvertise = new ArrayList<>();
		if (!allAdvertise.isEmpty()) {
			for (Advertise advertise : allAdvertise) {
				Address advAddress = advertise.getAddress();
				if (advertise.getPropertyType().equals(filterObj.getPropertyType())
						&& advertise.getPrice() >= filterObj.getminPrice()
						&& advertise.getPrice() <= filterObj.getMaxPrice() && advertise.getBhk() == filterObj.getBhk()
						&& advAddress.getCity().equals(filterObj.getCity())
						&& advAddress.getState().equals(filterObj.getState()))
					filteredAdvertise.add(advertise);
			}
			return filteredAdvertise;
		}
		return null;
	}

	@Override
	public List<RateEntryDto> listFilteredRateEntry(RateEntry filterObj) {
		System.out.println("FilterObj: " + filterObj);
		List<RateEntry> allRates = rateEntryRepo.findAll();
		System.out.println("Allrates: " + allRates);
		List<RateEntryDto> filteredRates = new ArrayList<>();

		if (!allRates.isEmpty()) {
			for (RateEntry rateEntry : allRates) {
				System.out.println(rateEntry);
				if (rateEntry.getSource().equals(filterObj.getSource())
						&& rateEntry.getDestination().equals(filterObj.getDestination())
						&& rateEntry.getRate() <= filterObj.getRate()) {
					Shifter tempShifter = rateEntry.getShifter();
					System.out.println("tempShifter: " + tempShifter);

					RateEntryDto tempRateEntry = new RateEntryDto(rateEntry.getEntryId(), rateEntry.getSource(),
							rateEntry.getDestination(), rateEntry.getRate(), tempShifter.getCompanyName(),
							tempShifter.getRating());

					filteredRates.add(tempRateEntry);
				}

			}
			filteredRates.sort(new sortByRate());
			return filteredRates;
		}
		return null;
	}

	@Override
	public List<Advertise> ListAdvertisement() {
		List<Advertise> listAdvertise = advRepo.findAll();
		Advertise a = null;
		if (!listAdvertise.isEmpty())
			return listAdvertise;
		else
			return null;
	}

	@Override
	public void cancelRequest(int requestId) {

		Optional<SeekerRequest> seekerRequest = requestRepo.findByRequestId(requestId);
		if (seekerRequest.isPresent()) {
			requestRepo.delete(seekerRequest.get());
		}

	}
}
