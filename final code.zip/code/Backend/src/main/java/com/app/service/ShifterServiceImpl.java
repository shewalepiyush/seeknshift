package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.RateEntryRepository;
import com.app.dao.RequestRepository;
import com.app.dao.ShifterRepository;
import com.app.dao.UserRepository;
import com.app.dto.ShifterDto;
import com.app.pojos.Advertise;
import com.app.pojos.RateEntry;
import com.app.pojos.Review;
import com.app.pojos.SeekerRequest;
import com.app.pojos.Shifter;
import com.app.pojos.User;

@Service
@Transactional
public class ShifterServiceImpl implements IShifterService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private RateEntryRepository rateEntryRepo;
	@Autowired
	private RequestRepository requestRepo;
	@Autowired
	private ShifterRepository shifterRepo;

	@Override
	public void addCompany(ShifterDto shifterDto) {

		Optional<User> optional = userRepo.findByUserId(shifterDto.getUserId());
		if (optional.isPresent()) {
			User u1 = optional.get();
			Shifter s = new Shifter();
			s.setUser(u1);
			s.setCompanyName(shifterDto.getcName());
			u1.setShifter(s);
			userRepo.save(u1);
		}
	}

	@Override
	public void addRateEntry(ShifterDto shifterDto) {
		Optional<User> optional = userRepo.findByUserId(shifterDto.getUserId());
		if (optional.isPresent()) {
			User user = optional.get();
			if(user.getPoints()>10) {
			user.setPoints(user.getPoints()-10);
			RateEntry r = new RateEntry();
			r.setDestination(shifterDto.getDestination());
			r.setSource(shifterDto.getSource());
			r.setRate(shifterDto.getRate());
			r.setShifter(user.getShifter());
			user.getShifter().getRateEntry().add(r);
			userRepo.save(user);}
		}
	}

	@Override
	public void deleteRateEntry(int id) {
		Optional<RateEntry> optional = rateEntryRepo.findByEntryId(id);
		if (optional.isPresent())
			rateEntryRepo.delete(optional.get());
	}

	@Override
	public void updateRateEntry(ShifterDto rateEntryHobj, int id) {
		Optional<RateEntry> optional = rateEntryRepo.findByEntryId(id);
		if (optional.isPresent()) {
			RateEntry rateEntry = optional.get();
			rateEntry.setSource(rateEntryHobj.getSource());
			rateEntry.setDestination(rateEntryHobj.getDestination());
			rateEntry.setRate(rateEntryHobj.getRate());
			rateEntryRepo.save(rateEntry);
		}
	}

	@Override
	public RateEntry getRateEntry(int id) {
		Optional<RateEntry> optional = rateEntryRepo.findByEntryId(id);
		RateEntry rateEntry = null;
		if (optional.isPresent()) {
			rateEntry = optional.get();
		}
		return rateEntry;
	}

	@Override
	public List<RateEntry> getAllRateEntry(int id) {
		Optional<User> optional = userRepo.findById(id);
		User shifter = null;
		List<RateEntry> rateEntries = null;
		if (optional.isPresent()) {
			shifter = optional.get();
			rateEntries = shifter.getShifter().getRateEntry();
		}
		return rateEntries;

	}

	@Override
	public List<SeekerRequest> getSeekerRequests(int userId) {
		System.out.println("in shifter service getSeekerRequests ");
		Optional<User> optional = userRepo.findById(userId);
		List<SeekerRequest> seekerRequest = new ArrayList<>();
		if (optional.isPresent()) {
			User user = optional.get();
			// u.getAdvertise().get(2).getSeekerRequests().get(0).getUser();
			for (RateEntry rateEntry : user.getShifter().getRateEntry()) {
				seekerRequest.addAll(rateEntry.getSeekerRequests());
			}
		}
		return seekerRequest;
	}

	@Override
	public List<Review> getSeekerReviews(int userId) {
		System.out.println("in shifter service getSeekerRequests ");
		Optional<User> optional = userRepo.findById(userId);
		if (optional.isPresent()) {
			User user = optional.get();
			return user.getShifter().getReview();
		}
		return null;
	}

	@Override
	public void approveRequest(int id) {
		Optional<SeekerRequest> optional = requestRepo.findByRequestId(id);
		if (optional.isPresent()) {
			SeekerRequest seekerRequest = optional.get();
			if (seekerRequest.getApproval() == 1)
				seekerRequest.setApproval(0);
			else
				seekerRequest.setApproval(1);
			requestRepo.save(seekerRequest);
		}
	}
	@Override
	public Shifter getcompanyname(int id) {
		Optional<User> optional = userRepo.findByUserId(id);
		if (optional.isPresent()) {
			User user = optional.get();
			return user.getShifter();
		}
		return null;
	}

}