package com.app.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.dao.UserRepository;
import com.app.dto.UserDto;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private IAdminService adminService;

	@Autowired
	private PasswordEncoder encoder;

	@Override
	public User getUserByEmailAndPassword(String email, String password) {
		System.out.println("in user service login function of email " + email);
		Optional<User> optional = userRepo.findByEmail(email);
		User u = null;
		if (optional.isPresent()) {
			u = optional.get();
			if (encoder.matches(password, u.getPassword()))
				return u;
		}
		return null;
	}

	@Override
	public User registerNewUser(User user) {
		System.out.println("in user service impl registering new user");
		user.setPassword(encoder.encode(user.getPassword()));
		return userRepo.save(user);
	}

	@Override
	public User updateUser(UserDto u) {
		Optional<User> optional = userRepo.findByUserId(u.getUserId());
		if (optional.isPresent()) {
			User u1 = optional.get();
			u1.setFirstName(u.getFirstName());
			u1.setLastName(u.getLastName());
			u1.setPhone(u.getPhone());
			u1.getAddress().setCity(u.getCity());
			u1.getAddress().setLocation(u.getLocation());
			u1.getAddress().setState(u.getState());
			return userRepo.save(u1);
		}
		return null;
	}

	@Override
	public User getUserByEmail(String email) {
		System.out.println("in method of getuserByEmail of userservice " + email);
		Optional<User> optional = userRepo.findByEmail(email);
		if (optional.isPresent())
			return optional.get();
		return null;
	}

	@Override
	public void deleteUser(int id) {
		Optional<User> optional = userRepo.findById(id);
		if (optional.isPresent()) {
			userRepo.delete(optional.get());
		}
	}

//	public void activateUser(int id) {
//		Optional<User> optional = userRepo.findByUserId(id);
//		if (optional.isPresent()) {
//			User u = optional.get();
//			adminService.sendSimpleEmail(u.getEmail().toString(), "User Activation",
//					"Congratulations! Your acccount is activated. Glad that you choose us...");
//			u.setStatus(1);
//			userRepo.save(u);
//		}
//	}

	public User activateUser(int id) {
		Optional<User> optional = userRepo.findByUserId(id);
		if (optional.isPresent()) {
			User u = optional.get();
			u.setStatus(1);
			return userRepo.save(u);
		}
		return null;
	}

	@Override
	public int addPoints(int id, int points) {
		User u = null;
		System.out.println("Inside seeker-addPoints()");
		Optional<User> optional = userRepo.findByUserId(id);
		if (optional.isPresent()) {
			u = optional.get();
			System.out.println(points);
			u.setPoints(u.getPoints() + points);
			userRepo.save(u);
		}
		return u.getPoints();
	}

	@Override
	public int deletePoints(User user) {
		User u = null;
		System.out.println("Inside seeker-removePoints()");
		Optional<User> optional = userRepo.findByEmail(user.getEmail());
		if (optional.isPresent()) {

			u = optional.get();
			u.setPoints(u.getPoints() - user.getPoints());
			userRepo.save(u);
		}
		return u.getPoints();
	}

	@Override
	public User getProfile(int userId) {
		System.out.println("in method of get profile ");
		Optional<User> optional = userRepo.findById(userId);
		if (optional.isPresent())
			return optional.get();
		return null;
	}

	@Override
	public User uploadImage(User u) {
		Optional<User> optional = userRepo.findById(u.getUserId());
		if (optional.isPresent()) {
			return userRepo.save(u);
		}
		return null;
	}
}
