package com.app.service;

import java.util.Comparator;

import com.app.dto.RateEntryDto;


public class sortByRate  implements Comparator<RateEntryDto> {
	
	public int compare(RateEntryDto a, RateEntryDto b) 
    { 
        return (int) (a.getRate() - b.getRate()); 
    } 
}
