# SeekAndShift

Group D1:

1) Saddam Sayyed 
2) Piyush Shewale 
3) Chandra sekhar
4) Vishal Thokade.


SCOPE : 

Aim of this project is to develop a real estate web application packers and movers services. 

The real estate system gives the functionality for buyers, allowing them to search for houses by features or address. Once buyer finds desirable property , he can choose packers and movers service.

It provides functionality for the seller/owner , authorize them to log into the system and add new advertisements or delete existing ones. Also they can see interested buyers for their property.

Movers manager can see customer requests for packers and movers service , approve their request and fulfill it.

At last Admin can see different buyers , owners and  movers activities , all the deal status . Admin can activate/deactivate users and owners or advertisements.

Seekers, Owners and Shifters will have to recharge points to use website services. If points are exhausted, they will have to recharge again.

For this each user will have to register an account with username, password and they will be rewarded with some welcome points.

Thanking you!