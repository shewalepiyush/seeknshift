import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  url = 'http://localhost:4000/admin'
  constructor(
    private router: Router,
    private httpClient: HttpClient
  ) { }
  login(email: string, password: string) {
    const body = {
      email: email,
      password: password
    }

    return this.httpClient.post(this.url + '/login', body)
  }
  getSeekers() {
    // add the token in the request header
    /*const httpOptions = {
     headers: new HttpHeaders({
       token: sessionStorage['token']
     })
   };*/
   
   return this.httpClient.get(this.url + '/listSeeker')
 }
 getOwners() {
  // add the token in the request header
//   const httpOptions = {
//    headers: new HttpHeaders({
//      token: sessionStorage['token']
//    })
//  };
 
 return this.httpClient.get(this.url + '/listOwner')
}
getShifters() {
//   // add the token in the request header
//   const httpOptions = {
//    headers: new HttpHeaders({
//      token: sessionStorage['token']
//    })
//  };
 
 return this.httpClient.get(this.url + '/listShifter')
}
getReviews() {
 
 return this.httpClient.get(this.url + '/listReview')
}

getDetails(){
  return this.httpClient.get(this.url + '/getDetails')
}

changeStatus(id) {
  // add the token in the request header
  
  return this.httpClient.get(this.url + "/changeStatus/" + id/*httpOptions*/)
}

canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
  if (sessionStorage['user'] == "admin") {
    return true
  }
  this.router.navigate([''])
  return false
}


}
