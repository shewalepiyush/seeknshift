import { AdminService } from './admin.service';
import { ListMoversManagersComponent } from './list-movers-managers/list-movers-managers.component';
import { ListOwnersComponent } from './list-owners/list-owners.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ListCustomersComponent } from './list-customers/list-customers.component';
import { LoginComponent } from './login/login.component';
import { ListReviewsComponent } from './list-reviews/list-reviews.component';

const routes: Routes = [
 {path : '' , component : LoginComponent },
 {path : 'dashboard' , canActivate:[AdminService], component : DashboardComponent },
 {path : 'seekers' , canActivate:[AdminService], component : ListCustomersComponent },
 {path : 'owners' , canActivate:[AdminService], component : ListOwnersComponent },
 {path : 'reviews' , canActivate:[AdminService], component : ListReviewsComponent },
 {path : 'shifters' , canActivate:[AdminService], component : ListMoversManagersComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
