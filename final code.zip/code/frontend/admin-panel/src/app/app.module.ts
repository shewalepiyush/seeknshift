import { AdminService } from './admin.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ListCustomersComponent } from './list-customers/list-customers.component';
import { ListOwnersComponent } from './list-owners/list-owners.component';
import { ListMoversManagersComponent } from './list-movers-managers/list-movers-managers.component';
import { ListReviewsComponent } from './list-reviews/list-reviews.component';
//import { Router } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    ListCustomersComponent,
    ListOwnersComponent,
    ListMoversManagersComponent,
    ListReviewsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  
  ],
  providers: [
    AdminService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
