import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  details
  constructor(
    private router: Router,
    //private httpClient: HttpClient
    private adminService: AdminService
  ) { }

  ngOnInit(): void {
    this.getDetails()
  }
  getDetails() {
    this.adminService.getDetails().subscribe
    ((response: any) => {
      console.log(response)
      this.details = response
      if (response) {
        console.log(response)
      }
    })
  }
  onLogout() { }

}
