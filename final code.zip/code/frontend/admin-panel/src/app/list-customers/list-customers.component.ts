import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-list-customers',
  templateUrl: './list-customers.component.html',
  styleUrls: ['./list-customers.component.css']
})
export class ListCustomersComponent implements OnInit {
  seekers
  constructor(
    private router : Router,

    //private httpClient: HttpClient
    private adminService : AdminService
  ) { }

  ngOnInit(): void {this.loadSeekers()
  }

  loadSeekers() {
    this.adminService
          .getSeekers()
      .subscribe(response => {
        if (response) {
          console.log(response)
          this.seekers = response
          console.log(this.seekers)
        } else {
          console.log(response)
        }
      })
  }
  changeStatus(request) {
    this.adminService.changeStatus(request.userId).subscribe(response => {
      console.log(response)
    })
   this.router.navigate(['/seekers']).then(() => { window.location.reload(); })
  }
}
