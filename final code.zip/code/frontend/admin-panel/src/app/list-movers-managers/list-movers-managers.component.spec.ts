import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMoversManagersComponent } from './list-movers-managers.component';

describe('ListMoversManagersComponent', () => {
  let component: ListMoversManagersComponent;
  let fixture: ComponentFixture<ListMoversManagersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListMoversManagersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListMoversManagersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
