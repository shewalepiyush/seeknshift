import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-list-movers-managers',
  templateUrl: './list-movers-managers.component.html',
  styleUrls: ['./list-movers-managers.component.css']
})
export class ListMoversManagersComponent implements OnInit {
  shifters
  constructor(
    private router: Router,
    //private httpClient: HttpClient
    private adminService : AdminService
  ) { }

  
  ngOnInit(): void {this.loadShifters()
  }

  loadShifters() {
    this.adminService
          .getShifters()
      .subscribe(response => {
        if (response ){
          this.shifters = response
          console.log(this.shifters)
        } else {
          console.log(response)
        }
      })
  }
  changeStatus(request) {
    this.adminService.changeStatus(request.userId).subscribe(response => {
      console.log(response)
    })
   this.router.navigate(['/shifters']).then(() => { window.location.reload(); })
  }
}
