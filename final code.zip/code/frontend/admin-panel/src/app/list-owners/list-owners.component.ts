import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-list-owners',
  templateUrl: './list-owners.component.html',
  styleUrls: ['./list-owners.component.css']
})
export class ListOwnersComponent implements OnInit {
  owners
  constructor(
    private router: Router,
    private adminService : AdminService
  ) { }

  
  ngOnInit(): void {this.loadOwners()
  }

  loadOwners() {
    this.adminService
          .getOwners()
      .subscribe(response => {
        if (response) {
          this.owners = response
          console.log(this.owners)
        } else {
          console.log(response)
        }
      })
  }
  changeStatus(request) {
    this.adminService.changeStatus(request.userId).subscribe(response => {
      console.log(response)
    })
   this.router.navigate(['/owners']).then(() => { window.location.reload(); })
  }
}