import { ListMoversManagersComponent } from './../list-movers-managers/list-movers-managers.component';
import { AdminService } from './../admin.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-reviews',
  templateUrl: './list-reviews.component.html',
  styleUrls: ['./list-reviews.component.css']
})
export class ListReviewsComponent implements OnInit {

  constructor(
    private router: Router,
    private httpClient: HttpClient,
    private adminService: AdminService
  ) { }
  reviews 
  ngOnInit(): void {
    this.loadReviews()
  }

  loadReviews(){
  this.adminService
    .getReviews()
    .subscribe(response => {
      console.log(response)
      this.reviews = response
      if (response) {
        console.log(response)
      }
    })
   // this.router.navigate(['/admin/reviews']).then(() => { window.location.reload(); })

}

changeStatus(shifter) {
  this.adminService.changeStatus(shifter.userId).subscribe(response => {
    console.log(response)
  })
  this.router.navigate(['/reviews']).then(() => { window.location.reload(); })
}
}


