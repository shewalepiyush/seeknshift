import { AdminService } from './../admin.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email = ''
  password = ''
  constructor(
    private router: Router,
    //private httpClient: HttpClient
    private adminService : AdminService

  ) { }

  ngOnInit(): void {
  }
  onLogin() {
    console.log(this.email)
    console.log(this.password)

    this.adminService
      .login(this.email, this.password)
      .subscribe(response => {
        if (response) {
          const data = response
          console.log("data : "+data)
          sessionStorage['user'] = data['email']
          sessionStorage['password'] = data['password']
          this.router.navigate(['/dashboard'])
        } else {
          alert('invalid email or password')
        }
      })
  }
}
