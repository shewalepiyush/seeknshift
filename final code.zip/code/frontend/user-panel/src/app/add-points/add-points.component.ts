import { AuthService } from './../auth/auth.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-points',
  templateUrl: './add-points.component.html',
  styleUrls: ['./add-points.component.css']
})
export class AddPointsComponent implements OnInit {

  availablepoints
  points
  constructor(
    private router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.authService.getpoints().subscribe(response => {
      if (response)
        this.availablepoints = response
        console.log(response)
    })
  }

  onaddpoints() {
    this.authService
      .addpoints(this.points)
      .subscribe(response => {
        if (response)
          console.log(response)
      }
      )
      this.router.navigate(['/addpoints']).then(() => { window.location.reload(); })
  }
routing(){
 if(sessionStorage['role']=="OWNER")
  this.router.navigate(['/owner']).then(() => { window.location.reload(); })
  if(sessionStorage['role']=="SHIFTER")
  this.router.navigate(['/shifter']).then(() => { window.location.reload(); })
  if(sessionStorage['role']=="SEEKER")
  this.router.navigate(['/seeker']).then(() => { window.location.reload(); })

}
}

