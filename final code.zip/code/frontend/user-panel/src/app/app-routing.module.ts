import { AddPointsComponent } from './add-points/add-points.component';
import { ShifterService } from './shifter/shifter.service';
import { OwnerService } from './owner/owner.service';
import { AuthService } from './auth/auth.service';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path: '', canActivate: [], redirectTo: 'auth/login', pathMatch: 'full' },
  {
    path: '',
    component: HomeComponent,
    canActivate: [AuthService],
    children: [
      { path: 'seeker', loadChildren: () => import('./seeker/seeker.module').then(m => m.SeekerModule) },
      { path: 'shifter', canActivate: [ShifterService], loadChildren: () => import('./shifter/shifter.module').then(m => m.ShifterModule) },
      { path: 'owner', canActivate: [OwnerService], loadChildren: () => import('./owner/owner.module').then(m => m.OwnerModule) },
    ]
  },
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule) },
  { path: 'addpoints', component:AddPointsComponent }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
