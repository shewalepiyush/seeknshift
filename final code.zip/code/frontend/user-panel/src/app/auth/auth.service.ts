import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  url = 'http://localhost:4000/'

  constructor(
    private router: Router,
    private httpClient: HttpClient) { }

  login(email: string, password: string) {
    const body = {
      email: email,
      password: password
    }
    return this.httpClient.post(this.url + 'user/login', body)
  }
  signup(user) {
    const body = user
    return this.httpClient.post(this.url + 'user/signup', body)
  }
  imageupload(file,id) {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(this.url + 'user/image/'+id, formData)
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (sessionStorage['id']) {
      return true
    }

    this.router.navigate(['/auth/login'])
    return false
  }
  getpoints() {
    return this.httpClient.get('http://localhost:4000/user/getpoints/'+sessionStorage['id'])
  }
  addpoints(points) {
    return this.httpClient.get('http://localhost:4000/user/addpoints/'+sessionStorage['id']+"/"+points)
  }
}