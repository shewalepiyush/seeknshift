import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email = ''
  password = ''
  url =''
  constructor(
    private router: Router,
    private authService: AuthService) {}

  ngOnInit(): void {
  }

  onLogin() {
    this.authService
      .login(this.email, this.password)
      .subscribe(response => {
        console.log(response)
        if (response['status']) {
          const data = response['res']
          console.log(data)
          sessionStorage['firstName'] = data['firstName']
          sessionStorage['lastName'] = data['lastName']
          sessionStorage['role'] = data['role']
          sessionStorage['id'] = data['userId']
          this.url = "/"+data['role'].toLowerCase( )+'/'
          this.router.navigate([this.url])
        } else {
      alert('invalid email or password')
         
       }
      })
      //if(!sessionStorage['id'])
      //alert('invalid email or password')
  }

}