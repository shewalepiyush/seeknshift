import { AuthService } from './../auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user = {
    firstName: "",
    lastName: "",
    phone: "",
    dateOfBirth: "",
    email: "",
    points : 100,
    password: "",
    role: "",
    address: {
      state: "",
      city: "",
      location: ""
    }
  }
file

  constructor(
    private router: Router,
    private authService: AuthService) { }

  ngOnInit(): void {
  }

  onFileChanged(event) {
     this.file = event.target.files[0]
  }
  onSignup() {
    console.log(this.user)
    this.authService.signup(this.user)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(this.file)
          this.authService.imageupload(this.file,response['userId']) .subscribe(response => {
            console.log(response)})
          console.log(response)
          this.router.navigate(['/auth/login'])
        }
      })
  }
}