import { ShifterService } from './../shifter/shifter.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  role = sessionStorage['role']
  constructor(private router: Router, private shifterService: ShifterService) { }

  ngOnInit(): void {
  }

  onLogout() {
    sessionStorage.removeItem('token')
    sessionStorage.removeItem('firstName')
    sessionStorage.removeItem('lastName')
    sessionStorage.removeItem('role')
    sessionStorage.removeItem('id')

    this.router.navigate(['/auth/login'])
  }

  getRole() {
    return sessionStorage['role']
  }


  userExists() {
    if (sessionStorage['role'])
      return true;
    else
      return false;
  }
}
