import { Router } from '@angular/router';
import { OwnerService } from './../owner.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-advertisement',
  templateUrl: './add-advertisement.component.html',
  styleUrls: ['./add-advertisement.component.css']
})
export class AddAdvertisementComponent implements OnInit {

  constructor(private router: Router, private ownerService: OwnerService) { }
  title = ''
  description = ''
  propertytype = ''
  price = 0
  state = ''
  city = ''
  location = ''
  bhk = ''
  file
  ngOnInit(): void {
  }
  onFileChanged(event) {
    this.file = event.target.files[0]
  }
  addadvertise() {
    console.log("out-1 image")
    this.ownerService.addadvertisement(this.title, this.description, this.propertytype, this.price, this.state, this.city, this.location, this.bhk)
      .subscribe(response => {
        if (response)
          console.log(response)
        this.ownerService.imageupload(this.file, response['advertiseId']).subscribe(response => {
          console.log(response)
         // this.router.navigate(['/owner']).then(() => { window.location.reload(); })
        })
      })
   
  }
}

