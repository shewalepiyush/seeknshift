import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayAdvertiseComponent } from './display-advertise.component';

describe('DisplayAdvertiseComponent', () => {
  let component: DisplayAdvertiseComponent;
  let fixture: ComponentFixture<DisplayAdvertiseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayAdvertiseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayAdvertiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
