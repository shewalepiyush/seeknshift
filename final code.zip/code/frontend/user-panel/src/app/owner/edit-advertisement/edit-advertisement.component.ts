import { Router } from '@angular/router';
import { OwnerService } from './../owner.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-advertisement',
  templateUrl: './edit-advertisement.component.html',
  styleUrls: ['./edit-advertisement.component.css']
})
export class EditAdvertisementComponent implements OnInit {
  title = ''
  description = ''
  propertytype = ''
  price = 0
  state = ''
  city = ''
  location = ''
  id = ''
  bhk = ''
  constructor(private router: Router, private ownerService: OwnerService) { }

  ngOnInit(): void {
    this.oneditadvertise(sessionStorage['advertiseId'])
  }
  oneditadvertise(id) {
    this.ownerService.getadvertise(id).subscribe(response => {
      console.log(response)
      if (response) {
        const advertise = response
        this.id = advertise['advertiseId']
        this.title = advertise['title']
        this.description = advertise['description']
        this.propertytype = advertise['propertyType']
        this.price = advertise['price']
        this.bhk = advertise['bhk']
        this.state = advertise['address']['state']
        this.city = advertise['address']['city']
        this.location = advertise['address']['location']
      }
    })
    sessionStorage.removeItem('advertiseId')
  }
  editadvertise() {
    this.ownerService.editadvertisement(this.title, this.description, this.propertytype, this.price, this.state, this.city, this.location, this.id, this.bhk)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
      })
    this.router.navigate(['/owner']).then(() => { window.location.reload(); })
  }
}

