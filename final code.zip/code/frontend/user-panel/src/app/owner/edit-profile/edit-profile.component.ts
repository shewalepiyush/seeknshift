import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { OwnerService } from '../owner.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  firstName = ''
  lastName = ''
  phone = 0
  email = ''
  dateOfBirth = ''
  password = ''
  state = ''
  city = ''
  location = ''

  constructor(private router: Router, private ownerService: OwnerService) { }
  ngOnInit(): void {
    this.oneditprofile()
  }
  oneditprofile() {
    this.ownerService.getprofile().subscribe(response => {
      console.log(response)
      if (response) {
        const profile = response
        this.firstName = profile['firstName']
        this.lastName = profile['lastName']
        this.phone = profile['phone']
        this.email = profile['email']
        this.password = profile['password']
        this.dateOfBirth = profile['dateOfBirth']
        this.state = profile['address']['state']
        this.city = profile['address']['city']
        this.location = profile['address']['location']
      }
    })
  }
  editprofile() {
    this.ownerService.editprofile(this.firstName, this.lastName, this.phone, this.email, this.dateOfBirth, this.password, this.city, this.location, this.state)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
        this.router.navigate(['/owner/displayprofile']).then(() => { window.location.reload(); })
      })
  }
}
