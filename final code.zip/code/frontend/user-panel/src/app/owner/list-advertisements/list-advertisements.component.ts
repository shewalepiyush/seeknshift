import { Router } from '@angular/router';
import { OwnerService } from './../owner.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-advertisements',
  templateUrl: './list-advertisements.component.html',
  styleUrls: ['./list-advertisements.component.css']
})
export class ListAdvertisementsComponent implements OnInit {
  advertisements
  constructor(private router: Router, private ownerService: OwnerService) { }
  ngOnInit(): void {
    this.loadadvertisements()
  }

  onEditadvertisement(advertisement) {
    sessionStorage['advertiseId'] = advertisement.advertiseId
    this.router.navigate(['/owner/editadvertise'])
  }
  ongetadvertisement(advertisement) {
    sessionStorage['advertiseId'] = advertisement.advertiseId
    this.router.navigate(['/owner/displayadvertise'])
  }
  onDeleteadvertisement(advertisement) {
    this.ownerService.deleteAdvertise(advertisement.advertiseId).subscribe(response => {
      console.log(response)
    })
    this.router.navigate(['/owner']).then(() => { window.location.reload(); })
  }

  loadadvertisements() {
    this.ownerService
      .getadvertisements()
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.advertisements = response
        }
      })
  }
}
