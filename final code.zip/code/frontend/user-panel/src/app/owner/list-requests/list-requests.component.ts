import { Router } from '@angular/router';
import { OwnerService } from './../owner.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-requests',
  templateUrl: './list-requests.component.html',
  styleUrls: ['./list-requests.component.css']
})
export class ListRequestsComponent implements OnInit {
  requests

  constructor(private router: Router,
    private ownerService: OwnerService) { }

  ngOnInit(): void {
    this.loadRequests()
  }

  loadRequests() {
    this.ownerService
      .getRequests()
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.requests = response
        }
      })
  }
  changeStatus(request) {
    this.ownerService.acceptRequest(request.requestId).subscribe(response => {
      console.log(response)
    })
    this.router.navigate(['/owner/listrequests']).then(() => { window.location.reload(); })
  }
  displaycustomer(request) {
    sessionStorage['userId'] = request.user.userId
    this.router.navigate(['/owner/displaycustomer'])
  }
}
