import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { AddAdvertisementComponent } from './add-advertisement/add-advertisement.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';
import { ListRequestsComponent } from './list-requests/list-requests.component';
import { ListAdvertisementsComponent } from './list-advertisements/list-advertisements.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayAdvertiseComponent } from './display-advertise/display-advertise.component';
import { EditAdvertisementComponent } from './edit-advertisement/edit-advertisement.component';

const routes: Routes = [
  {path: '', component: ListAdvertisementsComponent},
  {path: 'listadvertisements', component: ListAdvertisementsComponent},
  {path: 'listrequests', component: ListRequestsComponent},
  {path: 'displayadvertise', component: DisplayAdvertiseComponent},
  {path: 'displaycustomer', component: DisplayCustomerComponent},
  {path: 'displayprofile', component: DisplayProfileComponent},
  {path: 'addadvertise', component: AddAdvertisementComponent},
  {path: 'editadvertise', component: EditAdvertisementComponent},
  {path: 'editprofile', component: EditProfileComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OwnerRoutingModule { }
