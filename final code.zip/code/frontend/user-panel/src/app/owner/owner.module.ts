import { OwnerService } from './owner.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OwnerRoutingModule } from './owner-routing.module';
import { ListAdvertisementsComponent } from './list-advertisements/list-advertisements.component';
import { ListRequestsComponent } from './list-requests/list-requests.component';
import { DisplayAdvertiseComponent } from './display-advertise/display-advertise.component';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';
import { AddAdvertisementComponent } from './add-advertisement/add-advertisement.component';
import { EditAdvertisementComponent } from './edit-advertisement/edit-advertisement.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';


@NgModule({
  declarations: [ListAdvertisementsComponent, ListRequestsComponent, DisplayAdvertiseComponent, DisplayCustomerComponent, AddAdvertisementComponent, EditAdvertisementComponent, DisplayProfileComponent, EditProfileComponent],
  imports: [
    CommonModule,
    OwnerRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers:[OwnerService]
})
export class OwnerModule { }
