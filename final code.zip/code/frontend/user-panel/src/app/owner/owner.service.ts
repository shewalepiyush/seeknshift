import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OwnerService {
  url = 'http://localhost:4000/owner'

  constructor(private router: Router, private httpClient: HttpClient) { }

  getadvertisements() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/get-alladvertisements/" + sessionStorage['id']/*,httpOptions*/)
  }
  getRequests() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/listRequests/" + sessionStorage['id']/*httpOptions*/)
  }
  getadvertise(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/get-advertisement/" + id/*httpOptions*/)
  }
  acceptRequest(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/approve-request/" + id/*httpOptions*/)
  }
  getcustomer(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get("http://localhost:4000/user/getProfile/" + id/*,httpOptions*/)
  }
  getprofile() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get("http://localhost:4000/user/getProfile/" + sessionStorage['id']/*httpOptions*/)
  }

  deleteAdvertise(id) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.delete(this.url + "/delete-advertisement/" + id /*httpOptions*/)
  }
  addadvertisement(title, description, propertyType, price, state, city, location, bhk) {
    const body = {
      "title": title,
      "description": description,
      "propertyType": propertyType,
      "bhk": bhk,
      "price": price,
      "state": state,
      "city": city,
      "location": location,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post(this.url + '/add-advertisement', body)
  }
  editadvertisement(title, description, propertyType, price, state, city, location, id, bhk) {
    const body = {
      "title": title,
      "description": description,
      "propertyType": propertyType,
      "price": price,
      "state": state,
      "city": city,
      "location": location,
      "userId": id,
      "bhk": bhk
    }
    return this.httpClient.put(this.url + '/update-advertisement/' + id, body)
  }
  editprofile(firstName, lastName, phone, email, dateOfBirth, password, city, location, state) {
    const body = {
      "firstName": firstName,
      "lastName": lastName,
      "phone": phone,
      "email": email,
      //"dateOfBirth": dateOfBirth,
      //"password": password,
      "city": city,
      "location": location,
      "state": state,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post('http://localhost:4000/user/update-profile', body)
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (sessionStorage['role'] == "OWNER") {
      return true
    }
    sessionStorage.removeItem('id')
    this.router.navigate(['/auth/login'])
    return false
  }
  imagedownload(id) {
    return this.httpClient.get('http://localhost:4000/user/image/'+id)
  }
  imageupload(file,id) {
    console.log(id)
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(this.url + '/image/'+id, formData)
  }
}
