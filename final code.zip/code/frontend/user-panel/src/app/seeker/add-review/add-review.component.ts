import { Router } from '@angular/router';
import { SeekerService } from './../seeker.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent implements OnInit {
  rating = ''
  experience = ''
  //requestId = sessionStorage['requestId']
  constructor(private router: Router,private seekerService: SeekerService) { }

  ngOnInit(): void {
  }

  addReview(){
    this.seekerService.addReviewToShifter(this.rating, this.experience).subscribe(response => {
      if (response) {
        console.log(response)
      }
    })
    sessionStorage.removeItem('rateEntryId')
    this.deleteRequest(sessionStorage['requestId'])
  }

  deleteRequest(requestId){
    this.seekerService
    .cancelRequest(requestId)
    .subscribe(response => {
      console.log(response)
      if (response) {
        console.log(response)
        sessionStorage.removeItem('requestId')
      }
    })
    this.router.navigate(['/seeker']).then(() => { window.location.reload(); })
  }
}
