import { OwnerService } from './../../owner/owner.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-advertise',
  templateUrl: './display-advertise.component.html',
  styleUrls: ['./display-advertise.component.css']
})
export class DisplayAdvertiseComponent implements OnInit {

  advertise
  file
  constructor(private ownerService:OwnerService) { }

  ngOnInit(): void {
    this.loadadvertise(sessionStorage['advertiseId'])
  }
  loadadvertise(id) {
    this.ownerService
      .getadvertise(id)
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.advertise = response
          this.file = "./../../../assets/Images/" + this.advertise['image']
        }
      })
  }
}