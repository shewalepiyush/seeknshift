import { OwnerService } from './../../owner/owner.service';
import { SeekerService } from './../seeker.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-profile',
  templateUrl: './display-profile.component.html',
  styleUrls: ['./display-profile.component.css']
})
export class DisplayProfileComponent implements OnInit {
  profile
  file
  constructor(private seekerService: SeekerService) { }

  ngOnInit(): void {
    this.customerdetails()
  }

  customerdetails() {
    this.seekerService.getprofile().subscribe(response => {
      if (response) {}
        console.log(response)
        this.profile = response 
        this.file = "./../../../assets/Images/" + this.profile['profile_pic']
        console.log(this.file)
    })
  }
}