import { SeekerService } from './../seeker.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-advertisements',
  templateUrl: './list-advertisements.component.html',
  styleUrls: ['./list-advertisements.component.css']
})
export class ListAdvertisementsComponent implements OnInit {

  advertisements
  propertyType = 'NA'
	minPrice = 0  
	maxPrice = 0 
	bhk = 0 
	state = 'NA'
	city = 'NA'
  constructor(private router: Router, private seekerService: SeekerService) { }

  ngOnInit(): void {
    this.loadadvertisements()
  }

  loadFilteredAdvertise() {
    this.seekerService
    .getFilteredAdvertises(this.propertyType, this.minPrice, this.maxPrice, this.bhk, this.state, this.city)
    .subscribe(response => {
      console.log(response)
      if (response) {
        this.advertisements = response
      }
    })
  }
  
  details(advertise) {

  }

  onSendRequest(advertisement){
    this.seekerService
    .sendRequestToOwner(advertisement.advertiseId)
      .subscribe(response => {
      console.log(response)
      if (response) {
        this.advertisements = response
      }
    })
    this.router.navigate(['/seeker/listAllRequests']).then(() => { window.location.reload(); })
  }

  loadadvertisements() {
    this.seekerService
      .getAllAdvertisements()
        .subscribe(response => {
        console.log(response)
        if (response) {
          this.advertisements = response
        }
      })
  }
  ongetadvertisement(advertisement) {
    sessionStorage['advertiseId'] = advertisement.advertiseId
    this.router.navigate(['/seeker/displayadvertise'])
  }
  onCancel(){
    this.router.navigate(['/seeker/listAllAdvertisements']).then(() => { window.location.reload(); })
  }
}
