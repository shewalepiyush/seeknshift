import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListRateEntriesComponent } from './list-rate-entries.component';

describe('ListRateEntriesComponent', () => {
  let component: ListRateEntriesComponent;
  let fixture: ComponentFixture<ListRateEntriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListRateEntriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListRateEntriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
