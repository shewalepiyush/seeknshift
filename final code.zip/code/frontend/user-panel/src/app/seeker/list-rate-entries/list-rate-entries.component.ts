import { SeekerService } from './../seeker.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-rate-entries',
  templateUrl: './list-rate-entries.component.html',
  styleUrls: ['./list-rate-entries.component.css']
})
export class ListRateEntriesComponent implements OnInit {

  rateentries
  rateentry
  source =""
  destination=""
  rate =""

  constructor(private router: Router, private seekerService: SeekerService) { }

  ngOnInit(): void {
  }

  loadFilteredRateEntries() {
    this.seekerService
      .getRateEntries(this.source, this.destination, this.rate)
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.rateentries = response
        }
      })
  }

  onSendRequest(rateentryId){
    this.seekerService.
    sendRequestToShifter(rateentryId)
      .subscribe(response => {
      console.log(response)
      if (response) {
        this.rateentries = response
      }
    })
    //this.router.navigate(['/seeker/listAllRequests'])
    this.router.navigate(['/seeker/listAllRequests']).then(() => { window.location.reload(); })
  }
}
