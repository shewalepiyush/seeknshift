import { Router } from '@angular/router';

import { Component, OnInit } from '@angular/core';
import { SeekerService } from '../seeker.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {

  requests
  requestsToOwner
  requestsToShifter

  constructor(private router: Router,
    private seekerService: SeekerService  ) { }

  ngOnInit(): void {
    this.loadRequests()
  }

    loadRequests() {
    this.seekerService
      .getAllRequests()
      .subscribe(response => {
        console.log(response)
        
        if (response) 
          this.requests = response
      })
    }

  deleteRequest(requestId){
    this.seekerService
    .cancelRequest(requestId)
    .subscribe(response => {
      console.log(response)
      if (response) {
        this.requests = response
      }
    })
    this.router.navigate(['/seeker/listAllRequests']).then(() => { window.location.reload(); })
  }

  addReview(entryId,requestId){
    sessionStorage['rateEntryId'] = entryId
    sessionStorage['requestId'] = requestId
    this.router.navigate(['/seeker/addReviewToShifter'])
  }
}
