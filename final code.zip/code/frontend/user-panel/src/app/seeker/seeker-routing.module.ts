
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddReviewComponent } from './add-review/add-review.component';
import { DisplayAdvertiseComponent } from './display-advertise/display-advertise.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { ListAdvertisementsComponent } from './list-advertisements/list-advertisements.component';
import { ListRateEntriesComponent } from './list-rate-entries/list-rate-entries.component';
import { RequestComponent } from './request/request.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';

const routes: Routes = [
  {path: '', component: RequestComponent},
  {path: 'listAllAdvertisements', component: ListAdvertisementsComponent},
  {path: 'listAllRequests', component: RequestComponent},
  {path: 'listFilteredRateEntry', component: ListRateEntriesComponent},
  {path: 'displayProfile', component: DisplayProfileComponent},
  {path: 'updateProfile', component: UpdateProfileComponent},
  {path: 'addReviewToShifter', component: AddReviewComponent},
  {path: 'displayadvertise', component: DisplayAdvertiseComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SeekerRoutingModule { }
