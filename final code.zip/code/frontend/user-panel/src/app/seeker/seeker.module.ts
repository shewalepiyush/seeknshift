import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SeekerRoutingModule } from './seeker-routing.module';
import { ListAdvertisementsComponent } from './list-advertisements/list-advertisements.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RequestComponent } from './request/request.component'
import { SeekerService } from './seeker.service';
import { ListRateEntriesComponent } from './list-rate-entries/list-rate-entries.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { AddReviewComponent } from './add-review/add-review.component';
import { DisplayAdvertiseComponent } from './display-advertise/display-advertise.component';



@NgModule({
  declarations: [ListAdvertisementsComponent, RequestComponent, ListRateEntriesComponent, DisplayProfileComponent, UpdateProfileComponent, AddReviewComponent, DisplayAdvertiseComponent],
  imports: [
    CommonModule,
    SeekerRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    SeekerService
  ]
})
export class SeekerModule { }
