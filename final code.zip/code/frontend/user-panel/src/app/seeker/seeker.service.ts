import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SeekerService {

  url = 'http://localhost:4000/seeker'

  constructor(
    private httpClient: HttpClient
  ) { }

  getAllRequests() {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/listRequests/" +  sessionStorage['id'] , /*httpOptions*/)
  }

  getAllAdvertisements() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/listAllAdvertisement/"/*,httpOptions*/)
  }

  sendRequestToOwner(advertiseId) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/addRequestToOwner/" + advertiseId + "/" + sessionStorage['id']/*,httpOptions*/)
  }

  cancelRequest(requestId) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.delete(this.url + "/cancelRequest/" +  requestId /*httpOptions*/)
  }

  getRateEntries(source, destination, Maxrate) {
    const body = {
      "source": source,
      "destination": destination,
      "rate": Maxrate,
      "userId":sessionStorage['id']
    }
    return this.httpClient.post(this.url + "/listFilteredRateEntry/",body /*,httpOptions*/)
  }

  sendRequestToShifter(rateEntryId) {
    const body = {
      "rateEntryId" : rateEntryId,
      "userId" : sessionStorage['id']
      
    };
    return this.httpClient.post(this.url + "/addRequestToShifter/", body /*,httpOptions*/)
  }

  getprofile() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get("http://localhost:4000/user/getProfile/" + sessionStorage['id']/*httpOptions*/)
  }

  editprofile(firstName, lastName, phone, email, dateOfBirth, password, city, location, state) {
    const body = {
      "firstName": firstName,
      "lastName": lastName,
      "phone": phone,
      "email": email,
      //"dateOfBirth": dateOfBirth,
      //"password": password,
      "city": city,
      "location": location,
      "state": state,
      "userId":sessionStorage['id']
    }
    return this.httpClient.post('http://localhost:4000/user/update-profile', body)
  }


  addReviewToShifter(rating, experience){
    const body = {
      "rating": rating,
      "experience": experience
    }
    return this.httpClient.post('http://localhost:4000/seeker/addReviewToShifter/' + sessionStorage['rateEntryId'], body)
  }

  getFilteredAdvertises(propertyType, minPrice, maxPrice, bhk, state, city){
    const body = {
      "propertyType": propertyType,
      "minPrice": minPrice,
      "maxPrice": maxPrice,
      "bhk": bhk,
      "state": state,
      "city": city
    }
    return this.httpClient.post('http://localhost:4000/seeker/listFilteredAdvertise', body)
  }
}

