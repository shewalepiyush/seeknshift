import { SeekerService } from './../seeker.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  firstName = ''
  lastName = ''
  phone = 0
  email = ''
  dateOfBirth = ''
  password = ''
  state = ''
  city = ''
  location = ''

  constructor(private router: Router, private seekerService: SeekerService) { }

  ngOnInit(): void {
    this.oneditProfile()
  }

  oneditProfile() {
    this.seekerService.getprofile().subscribe(response => {
      console.log(response)
      if (response) {
        const profile = response
        this.firstName = profile['firstName']
        this.lastName = profile['lastName']
        this.phone = profile['phone']
        this.email = profile['email']
        this.password = profile['password']
        this.dateOfBirth = profile['dateOfBirth']
        this.state = profile['address']['state']
        this.city = profile['address']['city']
        this.location = profile['address']['location']
      }
    })
  }
  editProfile() {
    this.seekerService.editprofile(this.firstName, this.lastName, this.phone, this.email, this.dateOfBirth, this.password, this.city, this.location, this.state)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
        this.router.navigate(['/seeker/displayProfile']).then(() => { window.location.reload(); })
      })
  }
}
