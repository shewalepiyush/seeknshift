import { Router } from '@angular/router';
import { ShifterService } from './../shifter.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {
company=''
  constructor(private router: Router,private ShifterService: ShifterService) { }

  ngOnInit(): void {
  }
  addcompany() {
    this.ShifterService.addcompany(this.company)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
      })
      this.router.navigate(['/shifter']).then(() => { window.location.reload(); })
  }
}
