import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRateentryComponent } from './add-rateentry.component';

describe('AddRateentryComponent', () => {
  let component: AddRateentryComponent;
  let fixture: ComponentFixture<AddRateentryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddRateentryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRateentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
