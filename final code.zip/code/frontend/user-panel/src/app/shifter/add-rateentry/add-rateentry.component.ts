import { Router } from '@angular/router';
import { ShifterService } from './../shifter.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-rateentry',
  templateUrl: './add-rateentry.component.html',
  styleUrls: ['./add-rateentry.component.css']
})
export class AddRateentryComponent implements OnInit {
source =""
destination=""
rate =""
  constructor(private router :Router, private ShifterService: ShifterService) { }

  ngOnInit(): void {
  }
  addrateentry() {
    this.ShifterService.addrateentry(this.source, this.destination, this.rate)
      .subscribe(response => {
        console.log(response['error'])
        if (response) {
          console.log(response)
        }
      }
      )
      this.router.navigate(['/shifter/listrateentries']).then(() => { window.location.reload(); })
  }

}
