import { OwnerService } from './../../owner/owner.service';
import { ShifterService } from './../shifter.service';
import { SeekerService } from './../../seeker/seeker.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-customer',
  templateUrl: './display-customer.component.html',
  styleUrls: ['./display-customer.component.css']
})
export class DisplayCustomerComponent implements OnInit {
  customer
  file
  constructor(private ownerService:OwnerService) { }

  ngOnInit(): void {
    this.customerdetails(sessionStorage['userId'])
  }
customerdetails(id){
this.ownerService.getcustomer(id).subscribe(response=>{
  console.log(response)
  if (response) {
    console.log(response)
        this.customer = response 
        this.file = "./../../../assets/Images/" + this.customer['profile_pic']
        console.log(this.file)
  }
})
}
}
