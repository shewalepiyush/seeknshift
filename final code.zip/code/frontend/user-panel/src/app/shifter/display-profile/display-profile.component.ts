import { OwnerService } from './../../owner/owner.service';
import { ShifterService } from './../shifter.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-profile',
  templateUrl: './display-profile.component.html',
  styleUrls: ['./display-profile.component.css']
})
export class DisplayProfileComponent implements OnInit {
  profile
  file
  constructor(private ownerService: OwnerService) { }

  ngOnInit(): void {
    this.customerdetails()
  }
  customerdetails() {
    this.ownerService.getprofile().subscribe(response => {
      if (response) {}
        console.log(response)
        this.profile = response 
        this.file = "./../../../assets/Images/" + this.profile['profile_pic']
        console.log(this.file)
    })
  }
}
