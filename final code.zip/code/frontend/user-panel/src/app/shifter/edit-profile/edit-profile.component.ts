import { ShifterService } from './../shifter.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  firstName = ''
  lastName = ''
  phone = 0
  email = ''
  dateOfBirth = ''
  password = ''
  state = ''
  city = ''
  location = ''

  constructor(private router: Router, private ShifterService: ShifterService) { }
  ngOnInit(): void {
    this.oneditprofile()
  }
  oneditprofile() {
    this.ShifterService.getprofile().subscribe(response => {
      console.log(response)
      if (response) {
        const profile = response
        this.firstName = profile['firstName']
        this.lastName = profile['lastName']
        this.phone = profile['phone']
        this.email = profile['email']
        this.password = profile['password']
        this.dateOfBirth = profile['dateOfBirth']
        this.state = profile['address']['state']
        this.city = profile['address']['city']
        this.location = profile['address']['location']
      }
    })
  }
  editprofile() {
    this.ShifterService.editprofile(this.firstName, this.lastName, this.phone, this.email, this.dateOfBirth, this.password, this.city, this.location, this.state)
      .subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
        this.router.navigate(['/shifter/displayprofile']).then(() => { window.location.reload(); })
      })
  }
}
