import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRateentryComponent } from './edit-rateentry.component';

describe('EditRateentryComponent', () => {
  let component: EditRateentryComponent;
  let fixture: ComponentFixture<EditRateentryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditRateentryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRateentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
