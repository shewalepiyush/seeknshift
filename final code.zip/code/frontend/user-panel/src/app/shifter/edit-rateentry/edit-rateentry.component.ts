import { ShifterService } from './../shifter.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-rateentry',
  templateUrl: './edit-rateentry.component.html',
  styleUrls: ['./edit-rateentry.component.css']
})
export class EditRateentryComponent implements OnInit {
  source = ''
  destination = ''
  rate = ''
  entryId=''
  constructor(private router: Router, private ShifterService: ShifterService) { }

  ngOnInit(): void {
    this.oneditrateentry(sessionStorage['entryId'])
  }
  oneditrateentry(id) {
    this.ShifterService.getrateentry(id).subscribe(response => {
      console.log(response)
      if (response) {
        const rateentry = response
        this.entryId= rateentry['entryId']
        this.source = rateentry['source']
        this.destination = rateentry['destination']
        this.rate = rateentry['rate']
      }
    })
    sessionStorage.removeItem('entryId')
  }
  editrateentry() {
    this.ShifterService.editrateentry(this.source, this.destination, this.rate,this.entryId).subscribe(response => {
        console.log(response)
        if (response) {
          console.log(response)
        }
      })
    this.router.navigate(['/shifter/listrateentries']).then(() => { window.location.reload(); })
  }
}

