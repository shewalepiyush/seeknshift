import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListRateentriesComponent } from './list-rateentries.component';

describe('ListRateentriesComponent', () => {
  let component: ListRateentriesComponent;
  let fixture: ComponentFixture<ListRateentriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListRateentriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListRateentriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
