import { Router } from '@angular/router';
import { ShifterService } from './../shifter.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-rateentries',
  templateUrl: './list-rateentries.component.html',
  styleUrls: ['./list-rateentries.component.css']
})
export class ListRateentriesComponent implements OnInit {
rateentries
  constructor(private router: Router, private ShifterService: ShifterService) { }

  ngOnInit(): void {
    this.loadrateentries()
  }
  onEditrateentry(rateentry) {
    sessionStorage['entryId'] = rateentry.entryId
    this.router.navigate(['/shifter/editrateentry'])
  }
  onDeleterateentry(rateentry) {
    this.ShifterService.deleterateentry(rateentry.entryId).subscribe(response => {
      console.log(response)
    })
    this.router.navigate(['/shifter/listrateentries']).then(() => { window.location.reload(); })
  }

  loadrateentries() {
    this.ShifterService
      .getrateentries()
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.rateentries = response
        }
      })
  }
}
