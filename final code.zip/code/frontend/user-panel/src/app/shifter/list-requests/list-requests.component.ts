import { ShifterService } from './../shifter.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-requests',
  templateUrl: './list-requests.component.html',
  styleUrls: ['./list-requests.component.css']
})
export class ListRequestsComponent implements OnInit {
  requests
  constructor(private router: Router,
    private ShifterService: ShifterService) { }

  ngOnInit(): void {
    this.checkForCompany()
    this.loadRequests()
  }
  checkForCompany() {
    this.ShifterService.getcompany().subscribe(response => {
      console.log(response)
      if (!response['status']) 
        this.router.navigate(['/shifter/addcompany'])
    })
  }
  loadRequests() {
    this.ShifterService
      .getRequests()
      .subscribe(response => {
        console.log(response)
        if (response) {
          this.requests = response
        }
      })
  }
  changeStatus(request) {
    this.ShifterService.acceptRequest(request.requestId).subscribe(response => {
      console.log(response)
    })
    this.router.navigate(['/shifter/listrequests']).then(() => { window.location.reload(); })
  }
  displaycustomer(request) {
    sessionStorage['userId'] = request.user.userId
    this.router.navigate(['/shifter/displayseeker'])
  }
}
