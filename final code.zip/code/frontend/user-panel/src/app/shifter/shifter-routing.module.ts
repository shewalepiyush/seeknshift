import { AddCompanyComponent } from './add-company/add-company.component';
import { ListRateentriesComponent } from './list-rateentries/list-rateentries.component';
import { EditRateentryComponent } from './edit-rateentry/edit-rateentry.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';
import { AddRateentryComponent } from './add-rateentry/add-rateentry.component';
import { ListRequestsComponent } from './list-requests/list-requests.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', component: ListRequestsComponent },
  { path: 'listrequests', component: ListRequestsComponent },
  { path: 'addrateentry', component: AddRateentryComponent },
  { path: 'editprofile', component: EditProfileComponent },
  { path: 'editrateentry', component: EditRateentryComponent },
  { path: 'listrateentries', component: ListRateentriesComponent },
  { path: 'displayseeker', component: DisplayCustomerComponent },
  { path: 'addcompany', component: AddCompanyComponent },
  { path: 'displayprofile', component: DisplayProfileComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShifterRoutingModule { }
