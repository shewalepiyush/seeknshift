import { ListRequestsComponent } from './list-requests/list-requests.component';
import { ListRateentriesComponent } from './list-rateentries/list-rateentries.component';
import { EditRateentryComponent } from './edit-rateentry/edit-rateentry.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { DisplayProfileComponent } from './display-profile/display-profile.component';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';
import { AddRateentryComponent } from './add-rateentry/add-rateentry.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ShifterService } from './shifter.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShifterRoutingModule } from './shifter-routing.module';
import { AddCompanyComponent } from './add-company/add-company.component';

@NgModule({
  declarations: [AddRateentryComponent, DisplayCustomerComponent, DisplayProfileComponent, EditProfileComponent, EditRateentryComponent, ListRateentriesComponent, ListRequestsComponent, AddCompanyComponent],
  imports: [
    CommonModule,
    ShifterRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    ShifterService
  ]
})
export class ShifterModule { }
