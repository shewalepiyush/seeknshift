import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShifterService {

  url = 'http://localhost:4000/shifter'
  constructor(private router: Router,
    private httpClient: HttpClient
  ) { }


  getPrices(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    return this.httpClient.get(this.url + '/listPrices/' + id)
  }
  getprofile() {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get("http://localhost:4000/user/getProfile/" + sessionStorage['id']/*httpOptions*/)
  }

  getProfile(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };

    return this.httpClient.get(this.url + '/profile/' + id)
  }
  editprofile(firstName, lastName, phone, email, dateOfBirth, password, city, location, state) {
    const body = {
      "firstName": firstName,
      "lastName": lastName,
      "phone": phone,
      "email": email,
      //"dateOfBirth": dateOfBirth,
      //"password": password,
      "city": city,
      "location": location,
      "state": state,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post('http://localhost:4000/user/update-profile', body)
  }
  getcustomer(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get("http://localhost:4000/user/getProfile/" + id/*,httpOptions*/)
  }
  getRequests() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/listRequests/" + sessionStorage['id']/*httpOptions*/)
  }
  acceptRequest(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/approve-request/" + id/*httpOptions*/)
  }
  addrateentry(source, destination, rate) {
    const body = {
      "source": source,
      "destination": destination,
      "rate": rate,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post(this.url + '/addrateentry', body)
  }
  addcompany(company) {
    const body = {
      "cName": company,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post(this.url + '/addcompany', body)
  }
  deleterateentry(id) {
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.delete(this.url + "/delete-rateentry/" + id /*httpOptions*/)
  }
  getrateentries() {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/get-allrateentries/" + sessionStorage['id']/*,httpOptions*/)
  }
  getrateentry(id) {
    // add the token in the request header
    const httpOptions = {
      headers: new HttpHeaders({
        token: sessionStorage['token']
      })
    };
    return this.httpClient.get(this.url + "/get-rateentry/" + id/*httpOptions*/)
  }
  editrateentry(source, destination, rate, id) {
    const body = {
      "source": source,
      "destination": destination,
      "rate": rate,
      "userId": sessionStorage['id']
    }
    return this.httpClient.post(this.url + '/update-rateentry/' + id, body)
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (sessionStorage['role'] == "SHIFTER") {
      return true
    }
    sessionStorage.removeItem('id')
    this.router.navigate(['/auth/login'])
    return false
  }
  getcompany(){
    return this.httpClient.get(this.url + '/company-name/' + sessionStorage['id'])
  }

}

